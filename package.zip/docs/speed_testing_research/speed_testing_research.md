# Internet Speed Testing for Web Applications: Librespeed, Client-Side Libraries, Web APIs, Latency, Server Selection, and Accuracy for a React Implementation

## Executive Summary

Browser-based speed testing is mature enough to deliver credible download, upload, and latency metrics for consumer-grade networks without relying on paid API keys or proprietary SDKs. Three viable implementation paths exist today: self-hosted server-backed systems such as LibreSpeed and OpenSpeedTest; lightweight, all-client libraries and components; and measurement engines inspired by production-grade systems such as Cloudflare’s speedtest engine. Each path trades off control, accuracy, setup effort, and vendor dependencies.

- A self-hosted speed test using LibreSpeed provides the greatest control and privacy, requires no API keys, and can be deployed via Docker or classic LAMP stacks. It delivers download/upload throughput via HTTP transfers and approximate ping and jitter, with optional telemetry stored locally in MySQL/MariaDB.[^1][^2][^3][^4]
- Client-side-only approaches (e.g., OpenSpeedTest’s application, the react-internet-meter component, or bespoke fetch/XMLHttpRequest (XHR) loops) operate without any API keys and can be embedded into a React UI. They are simpler to deploy but have upload-measurement limitations and are more sensitive to browser behavior and HTTP intermediaries.[^16][^17][^18][^26][^34][^35]
- Web APIs can measure latency and related metrics: WebRTC getStats exposes round-trip time (RTT) and jitter suitable for interactive-quality diagnostics, while Navigation/Resource Timing and PerformanceResourceTiming provide HTTP-level timings including DNS lookup and request-start to response-start deltas.[^8][^9][^20][^21][^22][^23][^30]
- Accuracy depends on test design: larger transfers reduce TCP slow-start bias, careful use of workers avoids main-thread bottlenecks, and server capacity must exceed anticipated client rates. Empirical results show browser-based tests can under-report at high speeds, especially for uploads, and differ across browsers—underscoring the need for methodical design and calibration.[^29][^30][^31]

Recommendations for a React implementation:
- If you control infrastructure and value privacy and control, deploy LibreSpeed (Docker preferred) and integrate it into your React UI. This yields the most robust throughput measurements and straightforward server selection across multiple regions.[^1][^2][^3][^4]
- If you need a lightweight, API-key-free component embedded in a React app, use a client-only approach (OpenSpeedTest or react-internet-meter). Expect simpler deployment but fewer guarantees on upload accuracy and throughput ceilings.[^16][^17][^18][^34][^35]
- Always measure latency via WebRTC getStats (for RTC-like connections) or Navigation/Resource Timing for HTTP, and present jitter and RTT alongside throughput metrics.[^8][^9][^20][^21][^22][^23][^30]
- For server selection, use performance-based probing without external geolocation APIs: maintain a small, curated candidate set, run a brief pre-test (e.g., tiny HTTP downloads and HTTP RTT probes), select the best by a score combining latency and initial throughput, and fallback gracefully.[^21][^22][^23][^30]

The rest of this report details architecture, measurement methods, latency techniques, server selection, accuracy considerations, and a production-ready plan for integrating these components into a React application.

## Scope, Requirements, and Constraints

This report focuses on measuring download throughput, upload throughput, and latency (ping/RTT/jitter) in web applications without paid API keys or proprietary SDKs. The primary deployment target is modern browsers in desktop and mobile contexts, integrated into a React front end. The analysis considers:

- Client-only versus self-hosted/server-backed approaches, including Docker deployment options.
- Native browser APIs relevant to measurement: fetch and XHR for throughput; PerformanceNavigation/Resource Timing and WebRTC getStats for latency and network diagnostics; WebSocket ping/pong for app-layer RTT.
- Operational constraints: no external API keys, respect for privacy and telemetry choices, CORS, and CDN behavior.

Out of scope are native apps, desktop agents, and network-layer tools such as ICMP ping (not available to web pages).

## Approach A: Self-Hosted Speed Tests (LibreSpeed and OpenSpeedTest)

Self-hosted systems remain the most controllable path for credible network measurement. LibreSpeed and OpenSpeedTest both deliver HTML5 speed tests driven by HTTP transfers and JavaScript timing. They differ primarily in ecosystem and deployment ergonomics.

LibreSpeed architecture and deployment. LibreSpeed is a lightweight speed test implemented in JavaScript using XMLHttpRequest and Web Workers. It supports multiple server backends (PHP/Node) and can store telemetry in MySQL/MariaDB. Deployment is possible on Apache/nginx (classic LAMP) or via Docker (e.g., linuxserver image), with configuration files that can be customized and mounted. No API keys are required.[^1][^2][^3][^4] A practical installation guide exists for Debian/Ubuntu, covering basic Apache/PHP setup and optional database telemetry configuration.[^5] For experimentation, a Node.js backend variant exists.[^6]

OpenSpeedTest architecture and deployment. OpenSpeedTest provides a self-hosted speed test application built with vanilla JavaScript and built-in Web APIs. The project documents requirements (public IPv4/IPv6, a domain name) and offers deployment options including a Helm chart for Kubernetes. Like LibreSpeed, it focuses on HTTP-based throughput measurement and can operate without API keys.[^16][^17][^18][^19]

API keys and telemetry. Neither system requires API keys. LibreSpeed exposes telemetry configuration to store results locally if desired; operators can disable or enable telemetry and apply settings like ID obfuscation and password protection for stats. The public demo site notes its telemetry policy, illustrating what data may be collected when enabled.[^1][^5][^32]

Operational considerations. On the server side, ensure sufficient capacity (CPU, NIC, and disk I/O) to deliver high rates without saturation; test artifacts (e.g., large binary payloads) should be efficiently served and cached where appropriate. If multi-region tests are desired, deploy multiple instances and plan for server selection logic in the client.

To illustrate trade-offs, the following table compares the two self-hosted options.

Table 1. LibreSpeed vs OpenSpeedTest

| Dimension | LibreSpeed | OpenSpeedTest |
|---|---|---|
| License/Positioning | Free and open-source, lightweight HTML5 speed test | Free and open-source HTML5 speed test built with vanilla JS |
| Server backend | PHP (classic), Node variant; Apache/nginx; Docker image available | Self-hosted app; public deployment requirements documented; Kubernetes Helm chart |
| No-API-key requirement | No API keys required | No API keys required |
| Telemetry/Results | Optional MySQL/MariaDB telemetry; configurable settings; stats password and ID obfuscation options | Stores results in a database and provides a reporting system per self-hosted docs |
| Deployment complexity | LAMP or Docker; straightforward for single-server; multi-server support documented | Docker/Kubernetes-friendly; requires domain and public IPs |
| Customization | Templates and worker/customization supported via Docker mount points | Engine designed for HTTP throughput; configurable parameters in app |

LibreSpeed’s Docker route is often the fastest path to production. It lets you mount custom worker and client scripts, disable telemetry if needed, and standardize deployment across regions.[^2][^3] OpenSpeedTest’s Helm chart is attractive for teams standardizing on Kubernetes.[^18] Both align with the no-API-key requirement and offer operational control and privacy.

## Approach B: Client-Side Libraries and Components (No Server/Keys)

When self-hosting is not desirable or feasible, client-only speed tests can still provide useful metrics. These approaches rely on fetch/XHR to download known-size resources or POST uploads, timing the operations to estimate throughput.

Mechanics and trade-offs. A basic method loads an image or file of known size and measures the elapsed time until the resource completes. Variations use Web Workers to avoid main-thread contention and stream large payloads to reduce the influence of TCP slow start. Upload tests POST repeated chunks and measure the rate at which the browser and network can dispatch data.[^26][^34][^35]

Limitations. Client-only upload measurements can be inaccurate at higher bandwidths due to browser APIs, device performance, and server or intermediary behaviors (e.g., buffering, rate limiting). Without server cooperation, uploads depend on the target endpoint’s willingness to accept large payloads and the absence of front-end compression. Caching, CDNs, and proxy compression can distort download measurements if not accounted for. The method is also more susceptible to browser scheduling and device load.

Representative libraries:
- OpenSpeedTest’s app is a reference implementation of a pure client approach using built-in web APIs.[^16]
- react-internet-meter is a React component that estimates throughput via timed downloads of known-size resources; it can be configured with a custom image URL and size for calibration.[^34][^35]
- E7D speedtest and Comcast’s Speed-testJS are additional references for client-side throughput tests built on XHR and workers.[^25][^27]

Table 2. Client-side libraries/components

| Library/Component | Purpose | Dependencies | Upload support | Accuracy notes | Last known maintenance |
|---|---|---|---|---|---|
| OpenSpeedTest (client app) | Vanilla JS speed test using built-in Web APIs | None beyond browser | Yes (HTTP-based) | Good for demos; subject to high-bandwidth limits | Active open-source project |
| react-internet-meter | React component to estimate speed via downloads | React; image of known size | Not primary (download-focused) | Quick heuristic; less rigorous than server-backed tests | Published on npm |
| e7d/speedtest | Lightweight HTML5 speed test (XHR + workers) | None beyond browser | Yes (HTTP-based) | Similar constraints as other XHR-based tests | Open-source repository |
| Speed-testJS (Comcast) | Enriched browser-based speed test | Browser; optional backend for storage | Yes (HTTP-based) | Designed for richer UX; accuracy still bounded by HTTP and browser | Open-source repository |

These components shine for simple in-app checks (e.g., Is the connection good enough for HD streaming?) but should be paired with clear UX caveats about variability and limits.

## Measuring Throughput in the Browser: fetch/XHR/Web Workers

Throughput measurement hinges on timing the transfer of known quantities of data. XHR and fetch are the mainstays for these tests.

HTTP-level mechanics. The browser’s networking stack delivers resource timing entries that include when a request started and when the response started, plus DNS and TCP connect timings for the request. For downloads, a common technique is to request a large, cache-friendly payload (e.g., a static file of several megabytes) and compute bits-per-second from size and measured duration. For uploads, a known-size POST body is sent repeatedly while timing the operation. Worker threads are often used to isolate computation and avoid UI jank.[^21][^22][^23][^26]

Reducing measurement bias. TCP slow start and TLS handshakes can skew short transfers. Using larger files (tens of megabytes), multiple rounds, and discarding early small transfers helps stabilize estimates. Recording the maximum single-transfer rate can avoid averaging in the ramp-up period.[^29] Caching and compression must be controlled to prevent inflated results—preferring cache-disabled downloads of uncompressed artifacts or server-configured headers that ensure consistent handling across runs.[^26]

API differences. XHR offers progress events (e.g., “progress” and “load”) that are convenient for monitoring transfer completion and timing. Fetch provides a simpler promise-based API but less explicit progress streaming without more advanced patterns. In practice, both are constrained by the server’s behavior and any intermediaries. Where higher precision is needed, repeating tests and applying outlier suppression (e.g., trimmed mean) improves robustness.

Table 3. API comparison: fetch vs XHR vs Web Workers

| Aspect | fetch | XHR | Web Workers (for orchestration) |
|---|---|---|---|
| API model | Promise-based; simple request/response | Event-driven; progress, load, error | Separate thread; message passing |
| Progress visibility | Limited without ReadableStream; typically only final | Explicit progress events with loaded/total | Not a transport; used to run tests off main thread |
| Caching interactions | Subject to standard HTTP cache semantics | Same as fetch | N/A; but workers can choose cache-busting |
| Throughput impact | Similar at network level; JSON decode may add overhead | Similar; no built-in JSON parsing | Reduces UI contention during heavy transfers |
| Typical use in speed tests | Download of large blobs; fetch + stream (advanced) | Download/upload with progress events | Run tests, aggregate metrics, isolate from UI |

Practically, XHR’s progress events make it a good fit for straightforward throughput tests, while workers ensure the UI remains responsive. Where streaming is desired, fetch with streams can be considered by teams comfortable with more advanced patterns.[^26][^28]

## Measuring Ping/Latency: WebRTC getStats, HTTP Timing, and WebSocket

Latency is multi-faceted. For interactive quality diagnostics, RTT and jitter from WebRTC are insightful; for general web performance, HTTP timings and DNS resolution times provide a complementary view.

WebRTC RTT and jitter. The WebRTC statistics API (getStats) exposes metrics such as roundTripTime and jitter on RTP streams and candidate pairs. In peer-to-peer topologies, RTT reflects the path between peers; in topologies involving Selective Forwarding Units (SFUs), the reported RTT is between the client and the SFU, not end-to-end between two clients. To approximate end-to-end RTT with SFUs, you must sum the RTTs from each client to the SFU (and include SFU-to-SFU RTTs in cascaded scenarios), which requires correlating getStats across participants or using an aggregation framework.[^8][^9][^10][^11][^13][^14][^15][^30]

HTTP-based latency. Navigation and Resource Timing entries expose requestStart and responseStart, whose delta approximates server responsiveness from the client’s perspective, alongside DNS, TCP, and TLS timings. This “HTTP RTT” is not the same as network-layer RTT (e.g., ICMP ping) but is meaningful for web application performance. DNS lookup time can be derived from domainLookupStart and domainLookupEnd.[^20][^21][^22][^23][^33]

WebSocket keepalive and RTT. WebSocket implementations support ping/pong frames at the protocol level. While browsers do not surface these directly, servers can use them to detect broken connections and estimate latency. In the browser, application-level echo pings can be used to measure round-trip times at the WebSocket layer.[^24]

Table 4. Latency measurement methods

| Method | Metric captured | Pros | Cons | Typical use cases |
|---|---|---|---|---|
| WebRTC getStats (RTT, jitter) | RTT along media paths; jitter | Rich, real-time insight; works in RTC contexts | End-to-end RTT requires aggregation in SFU; not a general HTTP RTT | RTC quality diagnostics; live media |
| Navigation/Resource Timing | HTTP-level timings, including requestStart→responseStart, DNS | No special infra; available in all modern browsers | Affected by server queuing and caching; not network-layer RTT | Web performance profiling; server responsiveness checks |
| WebSocket ping/pong | App-layer RTT | Useful for real-time apps with WS | Requires server support; browser doesn’t expose raw ping/pong frames | Real-time app health checks; chat/streaming |

In summary, use WebRTC getStats for RTC path quality and HTTP timing for web responsiveness. If your application maintains a WebSocket channel, application-level pings can provide an additional, app-specific latency signal.

## Server Selection Without External Geolocation APIs

Credible speed testing begins with choosing a nearby, capable server. The constraint here is to avoid third-party geolocation APIs. The solution is to select based on measured performance from the client.

Performance-based selection. Maintain a small candidate set of servers (ideally in different regions). For each candidate:
- Perform a brief HTTP latency probe using requestStart→responseStart deltas and small downloads.
- If a WebRTC path is available (e.g., via your own signaling), use candidate pair RTT from getStats as an additional signal.
- Run a short, timed “pre-test” download (a few megabytes) to estimate available throughput.
- Combine these into a score (e.g., weighted sum of normalized latency and early throughput) and pick the best.[^21][^22][^23][^30]

DNS routing caveats. DNS-based geographic routing can be helpful but is not guaranteed to yield the closest or best path, as responses depend on the resolver’s location and routing policies. Client measurements remain the most reliable guide.[^36]

Iterative re-tests and failover. After initial selection, re-check periodically (e.g., every few minutes). If error rates or latency spike beyond thresholds, fail over to the next-best candidate. For multi-region deployments, this keeps the user on an optimal path without external geolocation.

Table 5. Server selection strategies

| Strategy | Pros | Cons | Operational notes |
|---|---|---|---|
| Performance-based probing | Most accurate; adapts to current conditions | Requires pre-test traffic and logic | Implement short pre-tests; cache best server; fall back on regression |
| DNS routing (geo-DNS) | Simple to implement | Not always optimal; depends on resolver location | Use as a hint, not a decision; combine with client measurements |
| Static nearest-by-deployment | Minimal logic | Often suboptimal; no adaptation | Acceptable for small footprint; pair with periodic client checks |

The hybrid approach—use DNS routing to narrow candidates, then select by measured performance—often yields the best user experience without external APIs.

## Accuracy Considerations and Test Design

Accuracy is a function of protocol behavior, browser implementation, device performance, and server capacity. Understanding these factors allows you to design tests that minimize bias and provide repeatable, interpretable results.

HTTP throughput behavior. TCP slow start and TLS handshakes affect short transfers disproportionately. Empirical studies have shown that recording the maximum sustained rate of larger transfers better reflects the bottleneck capacity than averaging small transfers that never reach steady state.[^29] Use multiple rounds, discard early ramps, and prefer larger payload sizes to stabilize estimates.

Client JavaScript performance. The browser’s JavaScript engine and event loop can become bottlenecks at high data rates. Different browsers exhibit slight variations in throughput at unconstrained gigabit rates, and client-side limitations can cause under-reporting, especially for uploads.[^29] Offloading work to Web Workers and avoiding main-thread heavy processing reduces this risk.

Server capacity and path saturation. Ensure server-side resources (CPU, NIC, storage I/O) exceed the maximum rate you intend to measure; otherwise, the server becomes the bottleneck. Consider TLS termination overhead and the impact of reverse proxies or load balancers.

Caching and compression. Cache hits and content compression can inflate throughput readings. Control this by serving cache-disabled, compression-consistent payloads during tests or by using endpoints designed for measurement rather than general site assets.[^26]

Jitter and stability windows. For jitter, compute the variability of inter-arrival times (e.g., from WebRTC jitter metrics or HTTP inter-response deltas) and define stability windows where measurements are taken. Report both median and variability metrics alongside peak rates.

Table 6. Accuracy factors and mitigations

| Factor | Impact | Mitigation |
|---|---|---|
| TCP slow start, TLS | Under-estimate on short transfers | Use larger payloads; discard ramp-up; repeat tests |
| Browser differences | Variability across browsers | Test on major browsers; use workers; trim outliers |
| Client CPU/event loop | Throughput ceilings, especially on uploads | Isolate in workers; minimize parsing on main thread |
| Server capacity | Server becomes the limiting factor | Benchmark server independently; scale capacity |
| Caching/compression | Inflated throughput | Disable cache; ensure consistent compression |
| Intermediaries (CDN/proxy) | Variable behavior | Use dedicated test endpoints; control headers |
| High-speed regimes | Under-reporting at high rates | Calibrate against reference tools; consider server-backed tests |

Design choices should be justified by controlled experiments. When precision at very high speeds is essential, consider server-backed designs (e.g., LibreSpeed) or pairing client-side heuristics with periodic server-verified tests.[^29][^30][^31]

## React Implementation Blueprint

A React application can integrate a speed test as a self-hosted service or as a client-only component. The right choice depends on infrastructure control, privacy requirements, and expected accuracy.

Option 1: Integrate a self-hosted LibreSpeed backend. Deploy LibreSpeed via Docker and embed the frontend into your React application. Present results and a “change server” selector backed by your regional deployments. Telemetry can be stored locally in MySQL/MariaDB; expose only aggregate or anonymized results to users. This approach offers robust throughput measurement and clearer control over test payloads.[^1][^2][^3][^4]

Option 2: Use a client-only component. For simpler needs, embed a component like react-internet-meter for quick connectivity checks. Pair it with HTTP timing probes to provide a fuller picture (latency plus heuristic throughput). Set expectations in UX about the indicative nature of the results.[^34][^35][^21][^22][^23]

Recommended architecture. Adopt a worker-driven test harness with hooks-based state updates in React. Offload heavy transfers and timing computations to a Web Worker to keep the UI responsive and reduce measurement bias. Expose results through a Redux/Zustand store or React Context to support charts and gauges.

UX and privacy. Always disclose what you are measuring, how long tests will run, and whether telemetry is stored. Provide controls to disable telemetry or opt out of uploads. Use gauges and charts that reflect uncertainty bands (e.g., show both median and peak rates, with jitter).

Operational notes. Ensure CORS is configured for any test endpoints and that assets are cache-busted during tests. If measuring through a CDN, prefer endpoints that bypass caching or set explicit headers to avoid cache pollution. Rate-limit tests and provide a manual “rerun” option rather than continuous auto-run.

Table 7. React integration options

| Option | Pros | Cons | Operational complexity | Accuracy |
|---|---|---|---|---|
| Self-hosted LibreSpeed | High control; robust throughput; privacy by design | Requires infra; server capacity planning | Moderate (Docker) | High for typical consumer speeds |
| Client-only (e.g., react-internet-meter) | Minimal setup; no keys; easy embed | Limited upload accuracy; browser variability | Low | Moderate/Indicative |
| Hybrid (client + server pre-check) | Better server selection; reduced bias | More moving parts | Moderate | High |

In production, many teams start with client-only for early validation and graduate to self-hosted when scale, accuracy, and privacy justify the operational investment.

## Testing, Monitoring, and Validation Plan

Reliability comes from disciplined validation across browsers, devices, and network conditions.

Test matrix. Exercise desktop and mobile browsers on a range of bandwidths and latencies, including constrained and unconstrained scenarios. Validate under different routing paths (e.g., Wi‑Fi vs Ethernet, VPN vs direct) and with varied server distances.

Validation against reference tools. When possible, compare results with established tools or server-side logs to ensure that client-side biases are understood. An academic evaluation of browser-based methods can guide expectations and point to known pitfalls.[^30] Longer-term monitoring benefits from structured reporting akin to Internet quality dashboards.[^31]

Reporting and telemetry. Store run metadata (timestamps, server, browser, device class) with results. Provide dashboards for median and percentile latencies and throughput distributions. Track drift across releases and parameterize test payload sizes to study their impact.

Edge cases. Address captive portals (no public internet), proxy/VPN routing, and failure modes (CORS blocks, timeouts, content caching). Implement explicit fallbacks and retries, and mark results as “degraded” under such conditions.

Table 8. Test scenarios matrix

| Scenario | Expected behavior | Success criteria |
|---|---|---|
| 10 Mbps download, 5 Mbps upload, 30 ms RTT | Stable throughput; HTTP latency ≈ 30–60 ms | ±10% throughput; RTT within expected range |
| 100 Mbps symmetric, 10 ms RTT | High throughput; minimal jitter | Peak rates reached; jitter low |
| 1 Gbps down/500 Mbps up (fiber) | Potential under-reporting in client-only | Server-backed test reaches near-line rate; client-only flags higher uncertainty |
| VPN routing | Increased RTT; stable throughput | Latency reflects VPN path; throughput not falsely depressed |
| Captive portal | Test fails or redirects | Graceful error; clear user messaging |

These scenarios provide a basis for regression testing and help calibrate expectations across devices and networks.

## Appendices: Reference Endpoints, API Surfaces, and Further Reading

Key API surfaces
- PerformanceNavigation/Resource Timing and PerformanceResourceTiming: requestStart, responseStart, domainLookupStart/domainLookupEnd for HTTP latency and DNS timings.[^20][^21][^22][^23]
- WebRTC getStats: roundTripTime and jitter on RTP streams and ICE candidate pairs.[^9][^30]
- WebSocket keepalive/pong: protocol-level heartbeat semantics.[^24]

LibreSpeed/OpeSpeedTest resources
- LibreSpeed source repository and Docker image documentation.[^1][^2][^3]
- Practical installation guide for LAMP deployment with optional telemetry.[^5]
- OpenSpeedTest self-hosted application, repository, and Kubernetes Helm chart.[^16][^17][^18]

Research and blogs
- Empirical evaluation of a browser-based bandwidth test and its limits.[^29]
- Academic work on web-based speed test design and accuracy.[^30]
- Internet quality dashboards and reporting concepts.[^31]
- HTTP timing-based latency discussion in browser contexts.[^33]

## Information Gaps

- Upload accuracy ceiling for client-only libraries across modern browsers remains incompletely quantified, especially beyond hundreds of megabits per second.
- End-to-end RTT measurement across SFU cascades requires aggregation frameworks not universally available; practical, generalizable methods for arbitrary topologies are still evolving.
- TURN relay impact on throughput tests (when direct P2P fails) varies by provider and is not standardized in public documentation.
- Comparative benchmarks across LibreSpeed, OpenSpeedTest, and bespoke fetch/XHR implementations under identical conditions are limited.
- Comprehensive, current licensing details for all derivative libraries (e.g., Comcast Speed-testJS) require verification against their repositories.

## References

[^1]: librespeed/speedtest - GitHub. https://github.com/librespeed/speedtest  
[^2]: LinuxServer.io Docs - librespeed (Docker). https://docs.linuxserver.io/images/docker-librespeed/  
[^3]: linuxserver/librespeed - Docker Image. https://hub.docker.com/r/linuxserver/librespeed  
[^4]: LibreSpeed - Speed Test (Official Site). https://librespeed.org/  
[^5]: Host Your Own Internet Speed Tester With LibreSpeed. https://i12bretro.wordpress.com/2021/11/11/host-your-own-internet-speed-tester-with-librespeed/  
[^6]: LibreSpeed/speedtest-mirror - Installation (Node.js) - Codeberg. https://codeberg.org/librespeed/speedtest-mirror/wiki/Installation-%28Node.js%29.md  
[^7]: Get started with WebRTC | web.dev. https://web.dev/articles/webrtc-basics  
[^8]: Calculating True End-to-End RTT (webrtcHacks). https://webrtchacks.com/calculate-true-end-to-end-rtt/  
[^9]: Identifiers for WebRTC's Statistics API (W3C TR). https://www.w3.org/TR/webrtc-stats/  
[^10]: RTCRtpSender.getStats() - MDN. https://developer.mozilla.org/en-US/docs/Web/API/RTCRtpSender/getStats  
[^11]: RTCIceCandidatePairStats - MDN. https://developer.mozilla.org/en-US/docs/Web/API/RTCIceCandidatePairStats  
[^12]: Official WebRTC samples - Peer connection (PC1). https://webrtc.github.io/samples/src/content/peerconnection/pc1/  
[^13]: ObserveRTC - Overview Introduction. https://observertc.org/docs/overview/introduction/  
[^14]: observeRTC - GitHub. https://github.com/observeRTC  
[^15]: observeRTC client-monitor-js - GitHub. https://github.com/observertc/client-monitor-js  
[^16]: OpenSpeedTest - Self-Hosted SpeedTest. https://openspeedtest.com/selfhosted-speedtest  
[^17]: openspeedtest/Speed-Test - GitHub. https://github.com/openspeedtest/Speed-Test  
[^18]: OpenSpeedTest Helm chart - GitHub. https://github.com/openspeedtest/Helm-chart  
[^19]: OpenSpeedTest: Check the Speed of your LAN via Web Browser - The New Stack. https://thenewstack.io/openspeedtest-check-the-speed-of-your-lan-via-web-browser/  
[^20]: Navigation and Resource Timing - MDN. https://developer.mozilla.org/en-US/docs/Web/Performance/Guides/Navigation_and_resource_timings  
[^21]: PerformanceResourceTiming - MDN. https://developer.mozilla.org/en-US/docs/Web/API/PerformanceResourceTiming  
[^22]: PerformanceResourceTiming.domainLookupStart - MDN. https://developer.mozilla.org/en-US/docs/Web/API/PerformanceResourceTiming/domainLookupStart  
[^23]: Assess loading performance with Navigation and Resource Timing - web.dev. https://web.dev/articles/navigation-and-resource-timing  
[^24]: Keepalive and latency - websockets (Python) docs. https://websockets.readthedocs.io/en/stable/topics/keepalive.html  
[^25]: e7d/speedtest - GitHub (lightweight HTML5 speed test). https://github.com/e7d/speedtest  
[^26]: High Performance Browser Networking - Chapter 15: XMLHttpRequest (O’Reilly). https://www.oreilly.com/library/view/high-performance-browser/9781449344757/ch15.html  
[^27]: Comcast/Speed-testJS - GitHub. https://github.com/Comcast/Speed-testJS  
[^28]: The Fetch API performance vs. XHR in vanilla JS - Go Make Things. https://gomakethings.com/the-fetch-api-performance-vs.-xhr-in-vanilla-js/  
[^29]: Performance of a Browser-Based JavaScript Bandwidth Test (Honors Thesis, 2013). https://people.computing.clemson.edu/~jmarty/HonorsProgram/ExampleHonorsTheses/DavidCohen-HonorsThesis2013.pdf  
[^30]: Design and Implementation of Web-based Speed Test Analysis Tool (CAIDA, 2022). https://www.caida.org/catalog/papers/2022_design_implementation_web_based_speedtest/design_implementation_web_based_speedtest.pdf  
[^31]: Introducing the Cloudflare Radar Internet Quality Page. https://blog.cloudflare.com/introducing-radar-internet-quality-page/  
[^32]: LibreSpeed - Speed Test (Privacy/Telemetry Info). https://librespeed.org/  
[^33]: Measuring End-to-End Latency in Web Browser (ipSpace.net Blog). https://blog.ipspace.net/2020/06/measuring-latency-in-browser/  
[^34]: react-internet-meter - npm. https://www.npmjs.com/package/react-internet-meter  
[^35]: Can I measure my users' internet speed in my react web app? - Stack Overflow. https://stackoverflow.com/questions/61471200/can-i-measure-my-users-internet-speed-in-my-react-web-app  
[^36]: How does geolocation-based DNS routing work? - falconcloud. https://falconcloud.ae/about/blog/how-does-geolocation-based-dns-routing-work/