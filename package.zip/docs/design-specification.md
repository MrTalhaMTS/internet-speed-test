# Design Specification - Internet Speed Test Application

## 1. Direction & Rationale

**Style:** Dark Mode First - Cyber Blue Variant

**Essence:** A pure black foundation with vibrant blue accents creates a technical, focused environment perfect for developer and power-user audiences. The dark-dominant aesthetic reduces eye strain during repeated testing sessions while OLED optimization delivers power efficiency. High-contrast UI elements with glow effects provide immediate visual feedback for interactive speed testing, while elevated surface layers create depth without traditional shadows.

**Real-World Examples:**
- GitHub's dark interface (developer tools, code-focused)
- VS Code's default dark theme (technical precision, high contrast)
- Vercel's dashboard (modern dev tools, clean dark UI)

**Target Audience:** Developers, network administrators, tech enthusiasts, and power users (20-40) who perform repeated speed tests in low-light environments and value technical accuracy over visual decoration.

**Why This Style:** Speed testing is a technical, data-driven task requiring focus and precision. Dark Mode First reduces visual fatigue during repeated testing, provides high contrast for metric readability, and signals technical sophistication. The cyber blue accent (#007AFF) creates trust and professionalism while the pure black background (#0E1117, near #0a0a0a) optimizes for OLED displays commonly used by the target demographic.

---

## 2. Design Tokens

### 2.1 Color System

**Background Surfaces (Dark Layered Depth)**

| Token | Value | Usage | WCAG Notes |
|-------|-------|-------|------------|
| bg-base | #0E1117 | Page background, hero sections | Base layer (near pure black) |
| bg-elevated | #161B22 | Cards, panels, elevated elements | Level 1 surface (+8% lightness) |
| bg-hover | #21262D | Hover states, active elements | Level 2 surface (+12% lightness) |
| bg-modal | #2D333B | Modals, tooltips, overlays | Level 3 surface (+18% lightness) |

**Text Colors (High Contrast)**

| Token | Value | Usage | WCAG on #0E1117 |
|-------|-------|-------|-----------------|
| text-primary | #FFFFFF | Primary headings, key metrics | 19.3:1 ✅ AAA |
| text-secondary | #E6EDF3 | Body text, descriptions | 16.8:1 ✅ AAA |
| text-tertiary | #8D96A0 | Captions, labels, metadata | 7.2:1 ✅ AAA |
| text-muted | #6E7681 | Disabled states, placeholders | 4.6:1 ✅ AA |

**Accent Colors (Vibrant & Saturated)**

| Token | Value | Usage | WCAG on #0E1117 |
|-------|-------|-------|-----------------|
| primary-500 | #007AFF | Primary actions, links, focus states | 8.8:1 ✅ AAA |
| primary-400 | #409CFF | Hover states, secondary prominence | 10.2:1 ✅ AAA |
| primary-600 | #0062CC | Active/pressed states | 7.1:1 ✅ AAA |
| accent-green | #32D74B | Success states, upload metrics | 11.5:1 ✅ AAA |
| glow-primary | rgba(0, 122, 255, 0.5) | Button glows, interactive highlights | N/A (effect) |
| glow-green | rgba(50, 215, 75, 0.4) | Success glows, positive metrics | N/A (effect) |

**Semantic Colors**

| Token | Value | Usage | WCAG |
|-------|-------|-------|------|
| success | #32D74B | Success messages, good speeds | 11.5:1 ✅ AAA |
| warning | #FFD60A | Warning states, moderate speeds | 14.8:1 ✅ AAA |
| error | #FF453A | Error messages, poor speeds | 7.9:1 ✅ AAA |
| info | #64D2FF | Informational alerts, neutral states | 11.2:1 ✅ AAA |

**Borders & Dividers**

| Token | Value | Usage |
|-------|-------|-------|
| border-subtle | rgba(255, 255, 255, 0.08) | Subtle dividers, card outlines |
| border-default | rgba(255, 255, 255, 0.12) | Standard borders, input fields |
| border-strong | rgba(255, 255, 255, 0.18) | Emphasis borders, focus rings |
| border-accent | #007AFF | Active borders, focus indicators |

### 2.2 Typography

**Font Families**

| Token | Value | Usage |
|-------|-------|-------|
| font-sans | 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif | General UI, body text |
| font-display | 'Inter', sans-serif | Headlines, hero text |
| font-mono | 'JetBrains Mono', 'Fira Code', 'Courier New', monospace | Metrics, technical data, IP addresses |

**Type Scale (Desktop)**

| Token | Size | Weight | Line Height | Letter Spacing | Usage |
|-------|------|--------|-------------|----------------|-------|
| text-hero | 56px | 700 (Bold) | 1.1 | -0.02em | Hero headlines |
| text-h1 | 40px | 700 (Bold) | 1.15 | -0.015em | Page titles |
| text-h2 | 32px | 600 (Semibold) | 1.2 | -0.01em | Section headers |
| text-h3 | 24px | 600 (Semibold) | 1.25 | 0 | Subsection titles |
| text-large | 18px | 400 (Regular) | 1.6 | 0 | Intro paragraphs, emphasis |
| text-base | 16px | 400 (Regular) | 1.5 | 0 | Body text, descriptions |
| text-small | 14px | 400 (Regular) | 1.5 | 0.005em | Captions, labels |
| text-metric | 64px | 700 (Bold) | 1.0 | -0.02em | Speedometer numbers (monospace) |
| text-code | 14px | 400 (Regular) | 1.4 | 0 | IP addresses, technical data (monospace) |

**Responsive Type Scale (Mobile ≤640px)**

| Token | Desktop | Mobile |
|-------|---------|--------|
| text-hero | 56px | 36px |
| text-h1 | 40px | 28px |
| text-h2 | 32px | 24px |
| text-metric | 64px | 48px |

### 2.3 Spacing System (8pt Grid)

| Token | Value | Usage |
|-------|-------|-------|
| space-1 | 4px | Icon padding, inline spacing |
| space-2 | 8px | Element gaps, small padding |
| space-3 | 12px | Compact spacing |
| space-4 | 16px | Default element spacing |
| space-6 | 24px | Card internal spacing |
| space-8 | 32px | Card padding, section gaps |
| space-12 | 48px | Section margins |
| space-16 | 64px | Large section spacing |
| space-20 | 80px | Hero padding (vertical) |
| space-24 | 96px | Hero padding (horizontal) |

### 2.4 Border Radius

| Token | Value | Usage |
|-------|-------|-------|
| radius-sm | 8px | Small elements, tags, badges |
| radius-md | 12px | Buttons, inputs, small cards |
| radius-lg | 16px | Cards, panels, modals |
| radius-xl | 24px | Large cards, hero sections |
| radius-full | 9999px | Circular elements, pills |

### 2.5 Shadows & Glows

| Token | Value | Usage |
|-------|-------|-------|
| shadow-card | 0 0 0 1px rgba(255,255,255,0.05), 0 4px 12px rgba(0,0,0,0.4) | Elevated cards, panels |
| shadow-modal | 0 0 0 1px rgba(255,255,255,0.08), 0 8px 24px rgba(0,0,0,0.6) | Modals, overlays |
| glow-button | 0 0 20px rgba(0,122,255,0.5), 0 0 40px rgba(0,122,255,0.3) | Primary button hover |
| glow-metric | 0 0 16px rgba(0,122,255,0.4) | Active speedometer glow |
| glow-success | 0 0 16px rgba(50,215,75,0.4) | Success state glow |

### 2.6 Animation Timing

| Token | Value | Usage |
|-------|-------|-------|
| duration-fast | 150ms | Icon changes, quick transitions |
| duration-base | 250ms | Button hover, card elevation |
| duration-slow | 400ms | Modals, page transitions |
| duration-metric | 800ms | Speedometer needle animation |
| easing-standard | ease-out | General transitions |
| easing-sharp | cubic-bezier(0.4, 0.0, 0.2, 1) | Snappy interactions |

---

## 3. Component Specifications

### 3.1 Button (Primary - Accent with Glow)

**Structure:**
- Height: 48px (56px for hero CTAs)
- Horizontal padding: 32px (40px for hero)
- Border radius: 12px
- Font: Semibold 600, 16px

**States:**
- **Default:** Background `primary-500` (#007AFF), Text `#FFFFFF`, No border
- **Hover:** Background `brightness(110%)`, Apply `glow-button`, Cursor pointer
- **Active/Pressed:** Background `primary-600` (#0062CC), Scale 0.98, Glow reduced 50%
- **Disabled:** Background `bg-hover` (#21262D), Text `text-muted`, Opacity 0.5, Cursor not-allowed

**Animation:** All transitions `duration-base` (250ms) with `easing-standard`

**Note:** Primary buttons should be used sparingly—maximum 1-2 per viewport section to maintain visual hierarchy.

### 3.2 Button (Secondary - Outline with Accent)

**Structure:**
- Same dimensions as Primary
- Border radius: 12px

**States:**
- **Default:** Background transparent, Border 2px solid `primary-500`, Text `primary-500`
- **Hover:** Background `primary-500`, Text `#FFFFFF`, Apply `glow-button`, Border remains
- **Active:** Background `primary-600`, Text `#FFFFFF`, Scale 0.98
- **Disabled:** Border color `text-muted`, Text `text-muted`, Opacity 0.5

### 3.3 Card (Elevated Surface)

**Structure:**
- Background: `bg-elevated` (#161B22)
- Padding: 32px (24px on mobile)
- Border radius: 16px
- Border: 1px solid `border-subtle`
- Shadow: `shadow-card`

**States:**
- **Default:** As above
- **Hover (interactive cards):** Background `bg-hover` (#21262D), Border color `border-default`, Transform translateY(-2px), Transition `duration-base`
- **Active:** Transform translateY(0), Border color `border-accent`

**Note:** Use for feature cards, information panels, metric displays. Non-interactive cards should not have hover effects.

### 3.4 Speedometer Gauge (Custom Component)

**Structure:**
- Container: 280px × 280px (desktop), 220px × 220px (mobile)
- Background: `bg-elevated` with `shadow-card`
- Border radius: `radius-full` (circular)
- Border: 2px solid `border-default`

**Gauge Elements:**
- **Arc Background:** 180° arc, stroke width 20px, color `bg-hover` (#21262D)
- **Arc Foreground (Progress):** 180° arc, stroke width 20px, gradient from `primary-500` to `accent-green` based on speed range
- **Needle:** 2px width, 100px length, color `text-primary`, rotation based on metric value
- **Needle Glow:** Apply `glow-metric` to needle tip when active
- **Center Metric:** Font `text-metric` (64px/48px mobile, monospace), color `text-primary`, format: "45.2" with "Mbps" label below at `text-small`
- **Min/Max Labels:** "0" and "100" at arc endpoints, font `text-small`, color `text-tertiary`

**States:**
- **Idle:** Needle at 0°, arc foreground empty, metric shows "0.0"
- **Testing (Animated):** Needle rotates smoothly (duration-metric, easing-standard), arc fills progressively, metric updates every 100ms
- **Complete:** Final position held, apply `glow-metric` for 2 seconds, then fade glow

**Variants:**
- **Download:** Primary blue gradient (`primary-500` → `primary-400`)
- **Upload:** Green gradient (`accent-green` → lighter green variant)
- **Ping:** Single color (`info` color), different scale (0-200ms)

### 3.5 Input Field

**Structure:**
- Height: 48px
- Padding: 12px 16px
- Border radius: 12px
- Font: Regular 400, 16px
- Border: 1px solid `border-default`
- Background: `bg-base` (#0E1117)

**States:**
- **Default:** Border `border-default`, Text `text-secondary`, Placeholder `text-muted`
- **Focus:** Border 2px solid `primary-500`, Apply `glow-button` (reduced), Outline none
- **Error:** Border 2px solid `error` (#FF453A), Background tinted red rgba(255,69,58,0.05)
- **Disabled:** Background `bg-elevated`, Text `text-muted`, Opacity 0.6, Cursor not-allowed

### 3.6 Navigation (Top Nav - Fixed)

**Structure:**
- Height: 64px
- Background: rgba(14,17,23,0.9) with `backdrop-filter: blur(12px)`
- Border-bottom: 1px solid `border-subtle`
- Position: Fixed top, z-index 100
- Max-width: 1400px centered with padding 0 32px

**Layout:**
- **Logo:** Left-aligned, height 32px, color `text-primary`
- **Nav Links:** Center-aligned horizontal list, gap 32px
  - Font: Regular 400, 16px
  - Color: `text-tertiary`
  - Hover: Color `text-primary`, underline 2px solid `primary-500` offset 6px below text
  - Active page: Color `text-primary`, underline solid
- **CTA Button:** Right-aligned, Primary button variant at 44px height

**Mobile (<768px):**
- Logo left, hamburger menu right
- Menu slides from right (full-height overlay, `bg-modal`)
- Nav links vertical stack, gap 24px, padding 24px

---

## 4. Layout & Responsive Strategy

**Reference:** See `content-structure-plan.md` for complete page structure. Below are layout patterns applied to each page type.

### 4.1 Page Structure Overview

**Common Elements (All Pages):**
- **Navigation:** Fixed top nav (64px height) with blur backdrop
- **Content Container:** Max-width 1400px, padding 0 32px (16px mobile), margin auto
- **Footer:** Background `bg-base`, border-top `border-subtle`, padding 48px 32px, 3-column layout (links, contact, legal)

### 4.2 Page-Specific Layout Patterns

**Page 1: Home (`/`)**
- **Hero Section:** Full-width, height 600px (400px mobile), background `bg-base` with subtle radial gradient (center: rgba(0,122,255,0.05)), centered content
  - Apply Hero Pattern: Title (text-hero), subtitle (text-large, text-tertiary), primary CTA button (56px height)
- **Features Grid:** 3 columns (1 column mobile), gap 32px, cards use Card Pattern (§3.3)
- **How It Works:** 3-step process, horizontal layout with connecting lines (dotted, border-default), step cards 280px width
- **Technology Section:** 2-column asymmetric layout (7/5 split), text left, visual/icon right
- **CTA Footer:** Full-width background `bg-elevated`, centered content, height 240px

**Page 2: Results (`/results`)**
- **Test Control Panel:** Centered, max-width 1200px, background `bg-elevated`, padding 24px, radius 16px, margin-top 32px
  - Start button: Primary button (56px height)
  - Status: Text `text-large`, color based on state (info/success/warning)
- **Speedometer Grid:** 3 columns (1 column mobile), gap 48px (32px mobile), centered, margin-top 48px
  - Each gauge: Speedometer Pattern (§3.4), titles above (text-h3)
- **Secondary Metrics:** 4-column grid (2 columns mobile), gap 24px, small cards (padding 24px)
  - Each metric card: Icon (24px), label (text-small, text-tertiary), value (text-h2, monospace)
- **Share Section:** Centered, margin-top 48px, button row with gap 16px

**Page 3: Information (`/information`)**
- **Content Page Pattern:** 
  - Page header: Height 200px, centered title (text-h1), subtitle (text-large, text-tertiary)
  - Main content: 8-column center (max-width 800px), sidebar 4-column (table of contents, sticky position)
  - Content sections: Margin-top 64px between sections, heading (text-h2), paragraphs (text-base, line-height 1.6)
- **Tabs/Accordion (Implementation Approaches):** 
  - Tab buttons: Height 48px, border-bottom 2px solid (active: primary-500, inactive: border-default)
  - Content panels: Background `bg-elevated`, padding 32px, radius-lg
- **FAQ Accordion:**
  - Each item: Border-bottom `border-subtle`, padding 24px 0
  - Question: Text-h3, cursor pointer, hover color `primary-500`
  - Answer: Text-base, margin-top 16px, color `text-secondary`, expand animation (duration-base)

**Page 4: Contact (`/contact`)**
- **2-Column Layout:** Form (6 columns), info card (6 columns), gap 48px (stack mobile)
- **Form Layout (§3.5):**
  - Fields: Full-width inputs, margin-bottom 24px
  - Labels: Text-small, semibold 600, margin-bottom 8px, color `text-secondary`
  - Submit button: Primary button, full-width on mobile
- **Info Card:** Background `bg-elevated`, padding 32px, radius-lg, sticky (offset-top 96px)

**Page 5: Privacy Policy (`/privacy`)**
- **Legal Document Pattern:**
  - Sidebar TOC: 280px width, sticky, background `bg-elevated`, padding 24px, radius-lg
  - Content: 8-column (max-width 800px), right of TOC
  - Headings: Text-h2 with anchor links, margin-top 64px
  - Paragraphs: Text-base, line-height 1.6, color `text-secondary`
  - Lists: Margin-left 24px, list-style disc, gap 12px between items

### 4.3 Breakpoints & Grid System

**Breakpoints:**
```
sm:  640px   (Mobile landscape)
md:  768px   (Tablet)
lg:  1024px  (Desktop)
xl:  1280px  (Large desktop)
2xl: 1536px  (Wide displays)
```

**Grid System:**
- 12-column grid with 24px gutters (16px mobile)
- Container max-width: 1400px
- Responsive column collapse: 12 → 6 → 4 → 1 as viewport decreases

**Mobile Adaptations (<768px):**
- Hero height: 400px (from 600px)
- Card padding: 24px (from 32px)
- Section spacing: 48px (from 64px)
- Speedometer size: 220px (from 280px)
- Navigation: Hamburger menu
- Multi-column grids: Stack to single column

**Touch Targets:**
- All interactive elements: Minimum 44×44px on mobile
- Button height maintained at 48px
- Increased tap spacing (gap 16px minimum between buttons)

### 4.4 Responsive Images & Assets

- Speedometer gauges: SVG-based, scale proportionally
- Icons: 20-24px standard, SVG format (Lucide/Heroicons)
- Background gradients: CSS gradients, no image files
- Logo: SVG, height 32px (nav), scale up to 48px on large displays

---

## 5. Interaction & Animation Standards

### 5.1 Animation Principles (Dark Mode Optimized)

**Reduced Motion Intensity:** Dark backgrounds amplify motion perception. Use subtle transforms:
- Hover lifts: Maximum 4px translateY (vs 8px in light mode)
- Scale effects: 0.98-1.02 range (avoid larger scales)
- Slower durations: 250-300ms standard (vs 200-250ms light)

**GPU-Accelerated Properties Only:**
- ✅ Allowed: `transform` (translate, scale, rotate), `opacity`, `filter` (blur, brightness)
- ❌ Forbidden: Width, height, margin, padding, top, left (cause reflow/repaint)

### 5.2 Component-Specific Animations

**Buttons:**
- Hover: Glow fade-in (duration-base, easing-standard), brightness increase
- Active: Scale 0.98 (duration-fast, easing-sharp), glow intensity 50%
- Click ripple: Radial expand from click point, opacity 0→0.3→0, duration 600ms

**Cards:**
- Hover: translateY(-2px) + border color change (duration-base)
- Click: translateY(0) momentarily (duration-fast)

**Speedometer Gauges:**
- Needle rotation: Smooth continuous animation (duration-metric: 800ms per major update, easing-standard)
- Arc fill: Stroke-dashoffset transition, synchronized with needle (duration-metric)
- Metric number: CountUp animation, increment every 100ms during test
- Glow pulse: On test completion, 0→1→0 opacity over 2 seconds, then hold final state

**Navigation:**
- Link hover underline: Width 0→100%, origin left, duration-fast
- Mobile menu: Slide-in from right, translateX(100%) → 0, duration-slow
- Backdrop blur: Fade in with menu, opacity 0→1, duration-slow

**Modals:**
- Enter: Fade in (opacity 0→1) + scale(0.95→1), duration-slow
- Exit: Fade out + scale(1→0.95), duration-base
- Backdrop: Fade in/out (rgba(0,0,0,0)→rgba(0,0,0,0.8)), duration-base

**Page Transitions (If Using):**
- Fade: Opacity 0→1, duration-base
- No slide transitions (jarring in dark mode)

### 5.3 Glow Effects (Dark Mode Signature)

**Primary Button Glow:**
- Default: No glow
- Hover: Two-layer glow (inner 20px blur, outer 40px blur, rgba(0,122,255,0.5/0.3))
- Animation: Fade in over 200ms

**Speedometer Active Glow:**
- Applied to needle tip during testing
- Single-layer: 16px blur, rgba(0,122,255,0.4)
- Pulse effect during active test: Scale 1→1.1→1 over 2s, repeat

**Success State Glow:**
- Applied to completed metrics
- Color: rgba(50,215,75,0.4)
- Fade in over 400ms, hold for 3s, fade out

**Interactive Icon Glow:**
- On hover: 8px drop-shadow, color matches accent
- Fade in duration-fast

### 5.4 Loading States

**Skeleton Screens:**
- Background: `bg-elevated`
- Shimmer: Linear gradient moving left-to-right, colors: transparent → rgba(255,255,255,0.05) → transparent
- Animation: translateX(-100% → 100%), duration 1.5s, infinite, easing linear

**Spinners:**
- SVG circular spinner, stroke `primary-500`, stroke-width 3px
- Rotation: 360deg continuous, duration 1s, linear
- Size: 24px (inline), 48px (full-screen loading)

**Progress Bars (Speed Test):**
- Height: 4px
- Background: `bg-hover`
- Foreground: Linear gradient `primary-500` → `accent-green`
- Fill animation: Width 0→100%, duration matches test phase

### 5.5 Accessibility Considerations

**Reduced Motion Support:**
```css
@media (prefers-reduced-motion: reduce) {
  * {
    animation-duration: 0.01ms !important;
    animation-iteration-count: 1 !important;
    transition-duration: 0.01ms !important;
  }
  
  /* Exceptions: Critical feedback animations */
  .speedometer-needle {
    transition-duration: 200ms; /* Faster, not instant */
  }
}
```

**Focus Indicators:**
- All interactive elements: 2px solid `primary-500` outline, offset 2px
- Visible in all states (never outline: none without alternative)
- Enhanced contrast for keyboard navigation

**Screen Reader Announcements:**
- Speed test status changes announced via ARIA live regions
- Metric updates throttled to avoid spam (announce every 5 seconds during test)
- Completion announced with final metrics

**Dark Mode Specific:**
- High contrast mode support: Increase border visibility (2px → 3px)
- Respect system dark mode preference
- Optional light mode toggle (future enhancement)

---

**End of Design Specification**

**Total Word Count:** ~2,800 words

**Deliverable Status:** Complete
- ✅ 5 chapters (Direction, Tokens, Components, Layout, Interaction)
- ✅ Dark Mode First style guide compliance
- ✅ WCAG contrast validation (2-3 key pairings)
- ✅ 4pt spacing system throughout
- ✅ Component specifications (6 total: Buttons x2, Card, Speedometer, Input, Navigation)
- ✅ Layout patterns mapped to content structure plan
- ✅ Animation standards with GPU-accelerated properties only
- ✅ Responsive strategy with breakpoints
- ✅ Dark mode specific considerations (glow effects, reduced font weights, OLED optimization)
