# Content Structure Plan - Internet Speed Test Application

## 1. Material Inventory

**Content Files:**
- `docs/speed_testing_research/speed_testing_research.md` (~7,500 words, 286 lines)
  - Sections: Executive Summary, LibreSpeed/OpenSpeedTest architecture, client-side libraries, throughput measurement, latency techniques, server selection, accuracy considerations, React implementation plan

**Visual Assets:**
- `imgs/` (empty - no pre-existing visual assets)
- Design will require: speedometer gauges, icons, data visualization elements

**Data Files:**
- None currently available
- Will need: Real-time speed test metrics (download/upload Mbps, ping ms, jitter ms)

## 2. Website Structure

**Type:** MPA (Multi-Page Application)

**Reasoning:** 
- Multiple distinct user goals: testing speed (interactive), learning about technology (informational), contacting support, understanding privacy
- 5 separate pages with different content types and purposes
- Combination of interactive tool + educational content + legal/contact pages
- Different user mental models for each page (action vs. information vs. legal)
- Aligns with standard web application structure for SEO and navigation clarity

## 3. Page/Section Breakdown

### Page 1: Home (`/`)
**Purpose:** Introduce the tool, start speed test, showcase features

**Content Mapping:**

| Section | Component Pattern | Data File Path | Content to Extract | Visual Asset (Content ONLY) |
|---------|------------------|-------------|--------------------|-----------------------------|
| Hero | Full-screen Hero with CTA | - | "Test Your Internet Speed" headline + "Accurate, Free, No Account Required" tagline | - |
| Quick Start | Primary CTA Button | - | "Start Speed Test" action button | - |
| Features Grid | Feature Card Grid (3 columns) | `docs/speed_testing_research.md` L1-18 | Extract 3 key features: "No API Keys Required", "Privacy-First Testing", "Real-Time Results" | - |
| How It Works | 3-Step Process Cards | `docs/speed_testing_research.md` L81-99 | Simplified explanation: "HTTP-based throughput measurement", "Web Workers for accuracy", "Real-time metric display" | - |
| Technology Brief | 2-column layout | `docs/speed_testing_research.md` L30-55 | Brief overview: LibreSpeed/OpenSpeedTest architecture, browser-based testing benefits | - |
| CTA Footer | Call-to-action Section | - | "Ready to test?" + navigation to Results page | - |

### Page 2: Results (`/results`)
**Purpose:** Display interactive speed test with live speedometer gauges

**Content Mapping:**

| Section | Component Pattern | Data File Path | Content to Extract | Visual Asset (Content ONLY) |
|---------|------------------|-------------|--------------------|-----------------------------|
| Test Control | Control Panel | - | Start/Stop test buttons, test status indicator | - |
| Primary Gauges | Speedometer Grid (3 gauges) | Real-time API | Display: Download speed (Mbps), Upload speed (Mbps), Ping latency (ms) | - |
| Secondary Metrics | Stat Cards Grid | Real-time API | Jitter (ms), Server location, IP address, ISP info | - |
| Progress Indicator | Linear Progress Bar | Real-time API | Test phase: "Testing download...", "Testing upload...", "Complete" | - |
| Historical Results | Results Table (optional) | Browser localStorage | Past 5 test results with timestamps | - |
| Share Actions | Social Share Buttons | - | Share results on social media, copy shareable link | - |

### Page 3: Information (`/information`)
**Purpose:** Educate users about speed testing technology and methodology

**Content Mapping:**

| Section | Component Pattern | Data File Path | Content to Extract | Visual Asset (Content ONLY) |
|---------|------------------|-------------|--------------------|-----------------------------|
| Page Header | Content Page Header | - | "How Speed Testing Works" title | - |
| Executive Summary | Highlight Box | `docs/speed_testing_research.md` L3-18 | Full executive summary content | - |
| Implementation Approaches | Accordion/Tabs | `docs/speed_testing_research.md` L30-79 | Section A: Self-hosted systems, Section B: Client-side libraries | - |
| Throughput Measurement | Content Section | `docs/speed_testing_research.md` L81-99 | HTTP-level mechanics, bias reduction, API differences | - |
| Latency Techniques | Content Section | `docs/speed_testing_research.md` L100-150 (estimated) | WebRTC, Navigation Timing, RTT measurement | - |
| Accuracy Factors | Content Section | `docs/speed_testing_research.md` L200-250 (estimated) | Test design considerations, calibration needs, browser differences | - |
| FAQ Accordion | Expandable FAQ | `docs/speed_testing_research.md` (extract key Q&A) | Common questions: "Why no API keys?", "How accurate?", "What affects results?" | - |

### Page 4: Contact (`/contact`)
**Purpose:** Allow users to reach out for support or feedback

**Content Mapping:**

| Section | Component Pattern | Data File Path | Content to Extract | Visual Asset (Content ONLY) |
|---------|------------------|-------------|--------------------|-----------------------------|
| Page Header | Content Page Header | - | "Get in Touch" title + "We'd love to hear from you" subtitle | - |
| Contact Form | Form Layout (6-col) | - | Fields: Name, Email, Subject, Message, Submit button | - |
| Contact Info | Info Card (6-col) | - | Alternative contact methods: Email address, response time expectations | - |
| Support Topics | Quick Links Grid | - | "Report a Bug", "Feature Request", "General Inquiry", "Privacy Question" | - |

### Page 5: Privacy Policy (`/privacy`)
**Purpose:** Legal documentation for data collection and privacy practices

**Content Mapping:**

| Section | Component Pattern | Data File Path | Content to Extract | Visual Asset (Content ONLY) |
|---------|------------------|-------------|--------------------|-----------------------------|
| Page Header | Legal Document Header | - | "Privacy Policy" title + last updated date | - |
| Table of Contents | Sticky TOC Sidebar | - | Section links: Data Collection, Telemetry, Cookies, Third Parties, User Rights | - |
| Policy Content | Legal Document Layout | `docs/speed_testing_research.md` L38 | Extract privacy principles: "No API keys", "Optional telemetry", "Local storage only" | - |
| Data Collection | Policy Section | - | What data is collected during tests: IP, ISP, speeds (no personal identification) | - |
| User Rights | Policy Section | - | Right to opt-out, data deletion, cookie management | - |

## 4. Content Analysis

**Information Density:** High
- 7,500+ words of technical documentation
- Complex technical concepts requiring clear explanation
- Interactive speed test tool with real-time data display
- Multiple user flows: test speed (action), learn technology (education), contact/privacy (support)

**Content Balance:**
- Technical Documentation: ~7,500 words (85%)
- Interactive Elements: Speed test gauges, forms (10%)
- Visual Assets: Speedometer visualizations, icons, UI graphics (5%)
- Content Type: **Mixed** (Technical/Data-driven + Interactive Tool)

**Key Content Characteristics:**
- Developer/power-user audience (20-40 age range per Dark Mode First style)
- Technical accuracy is critical (measurement methodology, privacy details)
- Real-time data visualization requirements (speedometer gauges, progress indicators)
- Privacy-focused messaging (no API keys, optional telemetry, local-first)
- Educational content requires clear information hierarchy
