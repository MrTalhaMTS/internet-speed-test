import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Mail, MessageSquare, Send } from 'lucide-react';

export const ContactPage: React.FC = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: '',
  });
  
  const [submitted, setSubmitted] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  
  const validateForm = () => {
    const newErrors: Record<string, string> = {};
    
    if (!formData.name.trim()) {
      newErrors.name = 'El nombre es requerido';
    }
    
    if (!formData.email.trim()) {
      newErrors.email = 'El correo electrónico es requerido';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = 'Por favor ingresa una dirección de correo válida';
    }
    
    if (!formData.subject.trim()) {
      newErrors.subject = 'El asunto es requerido';
    }
    
    if (!formData.message.trim()) {
      newErrors.message = 'El mensaje es requerido';
    } else if (formData.message.trim().length < 10) {
      newErrors.message = 'El mensaje debe tener al menos 10 caracteres';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (validateForm()) {
      // In a real app, this would send to a backend
      console.log('Form submitted:', formData);
      setSubmitted(true);
      
      // Reset form after 3 seconds
      setTimeout(() => {
        setFormData({ name: '', email: '', subject: '', message: '' });
        setSubmitted(false);
      }, 3000);
    }
  };
  
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    
    // Clear error when user starts typing
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: '' }));
    }
  };
  
  const topics = [
    { icon: <MessageSquare className="w-6 h-6" />, title: 'Consulta General', description: 'Preguntas sobre nuestro servicio' },
    { icon: <Mail className="w-6 h-6" />, title: 'Reportar un Error', description: '¿Encontraste un problema? Háznoslo saber' },
    { icon: <Send className="w-6 h-6" />, title: 'Solicitud de Función', description: 'Sugiere mejoras' },
  ];
  
  return (
    <div className="min-h-screen pt-24 pb-24">
      <div className="max-w-[1200px] mx-auto px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <h1 className="text-h1 text-text-primary mb-4">Contáctanos</h1>
          <p className="text-large text-text-tertiary">
            Nos encantaría saber de ti. Envíanos un mensaje y responderemos lo antes posible.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
          {/* Contact Form */}
          <div>
            <motion.form
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              onSubmit={handleSubmit}
              className="space-y-6"
            >
              {/* Name Field */}
              <div>
                <label htmlFor="name" className="block text-small font-semibold text-text-secondary mb-2">
                  Nombre
                </label>
                <input
                  type="text"
                  id="name"
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  className={`w-full px-4 py-3 bg-bg-base border rounded-md text-base text-text-secondary focus:outline-none focus:ring-2 focus:ring-primary-500 transition-all ${
                    errors.name ? 'border-error' : 'border-border-default'
                  }`}
                  placeholder="Tu nombre"
                />
                {errors.name && (
                  <p className="mt-2 text-small text-error">{errors.name}</p>
                )}
              </div>
              
              {/* Email Field */}
              <div>
                <label htmlFor="email" className="block text-small font-semibold text-text-secondary mb-2">
                  Correo Electrónico
                </label>
                <input
                  type="email"
                  id="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  className={`w-full px-4 py-3 bg-bg-base border rounded-md text-base text-text-secondary focus:outline-none focus:ring-2 focus:ring-primary-500 transition-all ${
                    errors.email ? 'border-error' : 'border-border-default'
                  }`}
                  placeholder="your.email@example.com"
                />
                {errors.email && (
                  <p className="mt-2 text-small text-error">{errors.email}</p>
                )}
              </div>
              
              {/* Subject Field */}
              <div>
                <label htmlFor="subject" className="block text-small font-semibold text-text-secondary mb-2">
                  Asunto
                </label>
                <select
                  id="subject"
                  name="subject"
                  value={formData.subject}
                  onChange={handleChange}
                  className={`w-full px-4 py-3 bg-bg-base border rounded-md text-base text-text-secondary focus:outline-none focus:ring-2 focus:ring-primary-500 transition-all ${
                    errors.subject ? 'border-error' : 'border-border-default'
                  }`}
                >
                  <option value="">Selecciona un asunto</option>
                  <option value="general">Consulta General</option>
                  <option value="bug">Reportar un Error</option>
                  <option value="feature">Solicitud de Función</option>
                  <option value="privacy">Pregunta sobre Privacidad</option>
                </select>
                {errors.subject && (
                  <p className="mt-2 text-small text-error">{errors.subject}</p>
                )}
              </div>
              
              {/* Message Field */}
              <div>
                <label htmlFor="message" className="block text-small font-semibold text-text-secondary mb-2">
                  Mensaje
                </label>
                <textarea
                  id="message"
                  name="message"
                  value={formData.message}
                  onChange={handleChange}
                  rows={6}
                  className={`w-full px-4 py-3 bg-bg-base border rounded-md text-base text-text-secondary focus:outline-none focus:ring-2 focus:ring-primary-500 transition-all resize-none ${
                    errors.message ? 'border-error' : 'border-border-default'
                  }`}
                  placeholder="Tu mensaje..."
                />
                {errors.message && (
                  <p className="mt-2 text-small text-error">{errors.message}</p>
                )}
              </div>
              
              {/* Submit Button */}
              <button
                type="submit"
                disabled={submitted}
                className="w-full px-6 py-3 bg-primary-500 text-white font-semibold rounded-md hover:brightness-110 hover:shadow-glow-button transition-all duration-250 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {submitted ? '¡Mensaje Enviado!' : 'Enviar Mensaje'}
              </button>
            </motion.form>
          </div>
          
          {/* Contact Information */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="space-y-8"
          >
            {/* Info Card */}
            <div className="bg-bg-elevated p-8 rounded-lg border border-border-subtle shadow-card sticky top-24">
              <h3 className="text-h3 text-text-primary mb-6">Información de Contacto</h3>
              
              <div className="space-y-6">
                <div>
                  <div className="flex items-center gap-3 mb-2">
                    <Mail className="w-5 h-5 text-primary-500" />
                    <h4 className="text-base font-semibold text-text-primary">Correo Electrónico</h4>
                  </div>
                  <p className="text-base text-text-secondary ml-8">
                    support@speedtest.com
                  </p>
                </div>
                
                <div>
                  <div className="flex items-center gap-3 mb-2">
                    <MessageSquare className="w-5 h-5 text-primary-500" />
                    <h4 className="text-base font-semibold text-text-primary">Tiempo de Respuesta</h4>
                  </div>
                  <p className="text-base text-text-secondary ml-8">
                    Generalmente respondemos en 24-48 horas
                  </p>
                </div>
              </div>
            </div>
            
            {/* Support Topics */}
            <div>
              <h3 className="text-h3 text-text-primary mb-4">Temas Comunes</h3>
              <div className="grid grid-cols-1 gap-4">
                {topics.map((topic, index) => (
                  <div
                    key={index}
                    className="bg-bg-elevated p-6 rounded-lg border border-border-subtle hover:bg-bg-hover transition-colors"
                  >
                    <div className="flex items-start gap-4">
                      <div className="text-primary-500">{topic.icon}</div>
                      <div>
                        <h4 className="text-base font-semibold text-text-primary mb-1">
                          {topic.title}
                        </h4>
                        <p className="text-small text-text-secondary">{topic.description}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
};
