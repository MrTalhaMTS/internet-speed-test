import React from 'react';
import { motion } from 'framer-motion';

export const PrivacyPage: React.FC = () => {
  const sections = [
    {
      id: 'resumen',
      title: 'Resumen General',
      content: `Esta Política de Privacidad describe cómo recopilamos, usamos y protegemos la información cuando utilizas nuestro servicio de Prueba de Velocidad de Internet. Estamos comprometidos a proteger tu privacidad y garantizar transparencia en nuestras prácticas de datos.`,
    },
    {
      id: 'recopilacion',
      title: 'Recopilación de Datos',
      content: `Nuestra prueba de velocidad opera completamente en tu navegador web y no recopila ni almacena información personal. Durante la prueba, procesamos temporalmente:
      
      • Métricas de rendimiento de red (velocidad de descarga, velocidad de subida, ping, latencia)
      • Marcas de tiempo de la prueba
      • Información técnica básica necesaria para que la prueba funcione
      
      No se recopila ni almacena información de identificación personal en nuestros servidores. Tu dirección IP no se registra ni rastrea.`,
    },
    {
      id: 'almacenamiento',
      title: 'Almacenamiento Local',
      content: `Los resultados de las pruebas se almacenan localmente en tu navegador utilizando localStorage. Estos datos incluyen:
      
      • Tus últimos 5 resultados de prueba de velocidad
      • Marcas de tiempo de las pruebas
      • Mediciones de velocidad
      
      Estos datos nunca salen de tu dispositivo y pueden borrarse en cualquier momento limpiando el almacenamiento local o la caché de tu navegador.`,
    },
    {
      id: 'cookies',
      title: 'Cookies y Rastreo',
      content: `No utilizamos cookies con fines de rastreo o publicidad. No utilizamos servicios de análisis de terceros. Tu uso de este servicio es completamente anónimo.`,
    },
    {
      id: 'terceros',
      title: 'Servicios de Terceros',
      content: `Nuestra prueba de velocidad se conecta a servidores de prueba para medir la velocidad de tu conexión. Estas conexiones son temporales y solo ocurren durante las pruebas activas. Utilizamos la infraestructura de Cloudflare para las pruebas de velocidad, pero no se comparten datos personales con estos servicios.`,
    },
    {
      id: 'seguridad',
      title: 'Seguridad de Datos',
      content: `Todas las operaciones de prueba de velocidad se realizan a través de conexiones HTTPS seguras. Dado que los resultados de las pruebas se almacenan localmente en tu navegador, tienes control completo sobre estos datos. No tenemos acceso a tus resultados de prueba.`,
    },
    {
      id: 'derechos',
      title: 'Tus Derechos',
      content: `Tienes control completo sobre tus datos:
      
      • Puedes borrar el historial de pruebas en cualquier momento limpiando el almacenamiento local de tu navegador
      • Puedes usar el servicio sin crear una cuenta
      • Puedes dejar de usar el servicio en cualquier momento
      • No se recopila información personal que requiera solicitudes de eliminación`,
    },
    {
      id: 'menores',
      title: 'Privacidad de Menores',
      content: `Nuestro servicio no recopila intencionalmente información de menores de 13 años. La prueba de velocidad puede ser utilizada por cualquier persona, pero no se recopila información personal de ningún usuario, independientemente de su edad.`,
    },
    {
      id: 'cambios',
      title: 'Cambios a Esta Política',
      content: `Podemos actualizar esta Política de Privacidad de vez en cuando. Cualquier cambio se publicará en esta página con una fecha de revisión actualizada. Te recomendamos revisar esta política periódicamente.`,
    },
    {
      id: 'contacto',
      title: 'Contáctanos',
      content: `Si tienes preguntas sobre esta Política de Privacidad, por favor contáctanos a través de nuestra página de contacto.`,
    },
  ];
  
  return (
    <div className="min-h-screen pt-24 pb-24">
      <div className="max-w-[1200px] mx-auto px-8">
        {/* Header */}
        <div className="mb-12">
          <h1 className="text-h1 text-text-primary mb-4">Política de Privacidad</h1>
          <p className="text-base text-text-tertiary">
            Última actualización: 3 de noviembre de 2025
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12">
          {/* Sticky Table of Contents */}
          <div className="md:col-span-1">
            <div className="bg-bg-elevated p-6 rounded-lg border border-border-subtle sticky top-24">
              <h3 className="text-base font-semibold text-text-primary mb-4">Tabla de Contenidos</h3>
              <nav className="space-y-2">
                {sections.map((section) => (
                  <a
                    key={section.id}
                    href={`#${section.id}`}
                    className="block text-small text-text-tertiary hover:text-primary-500 transition-colors"
                  >
                    {section.title}
                  </a>
                ))}
              </nav>
            </div>
          </div>
          
          {/* Content */}
          <div className="md:col-span-3 space-y-16">
            {sections.map((section, index) => (
              <motion.section
                key={section.id}
                id={section.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                viewport={{ once: true }}
                className="scroll-mt-24"
              >
                <h2 className="text-h2 text-text-primary mb-6">{section.title}</h2>
                <div className="prose prose-invert max-w-none">
                  {section.content.split('\n\n').map((paragraph, pIndex) => (
                    <p key={pIndex} className="text-base text-text-secondary mb-4 whitespace-pre-line">
                      {paragraph}
                    </p>
                  ))}
                </div>
              </motion.section>
            ))}
          </div>
        </div>
        
        {/* Privacy Highlights Box */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          viewport={{ once: true }}
          className="mt-16 bg-primary-500/5 border border-primary-500/20 rounded-lg p-8"
        >
          <h3 className="text-h3 text-text-primary mb-4">Aspectos Destacados de Privacidad</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div>
              <h4 className="text-base font-semibold text-text-primary mb-2">Sin Registro</h4>
              <p className="text-small text-text-secondary">
                Usa nuestro servicio sin crear una cuenta o proporcionar información personal
              </p>
            </div>
            <div>
              <h4 className="text-base font-semibold text-text-primary mb-2">Sin Rastreo</h4>
              <p className="text-small text-text-secondary">
                No rastreamos tu dirección IP, ubicación o historial de navegación
              </p>
            </div>
            <div>
              <h4 className="text-base font-semibold text-text-primary mb-2">Solo Datos Locales</h4>
              <p className="text-small text-text-secondary">
                Los resultados de las pruebas se almacenan localmente en tu navegador y nunca se envían a nuestros servidores
              </p>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
};
