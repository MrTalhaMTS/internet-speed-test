import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Play, Share2, Twitter, Facebook, Linkedin, Download, Upload, Activity } from 'lucide-react';
import { Speedometer } from '../components/Speedometer';
import { runSpeedTest, SpeedTestState, SpeedTestResult, saveTestResult, getTestHistory } from '../lib/speedTest';

export const ResultsPage: React.FC = () => {
  const [testState, setTestState] = useState<SpeedTestState>({
    phase: 'idle',
    downloadSpeed: 0,
    uploadSpeed: 0,
    ping: 0,
    jitter: 0,
    progress: 0,
    error: null,
  });
  
  const [testResult, setTestResult] = useState<SpeedTestResult | null>(null);
  const [history, setHistory] = useState<SpeedTestResult[]>(getTestHistory());
  
  const handleStartTest = async () => {
    setTestState({
      phase: 'ping',
      downloadSpeed: 0,
      uploadSpeed: 0,
      ping: 0,
      jitter: 0,
      progress: 0,
      error: null,
    });
    setTestResult(null);
    
    try {
      const result = await runSpeedTest((update) => {
        setTestState((prev) => ({ ...prev, ...update }));
      });
      
      setTestResult(result);
      saveTestResult(result);
      setHistory(getTestHistory());
    } catch (error) {
      console.error('Test failed:', error);
    }
  };
  
  const getPhaseText = () => {
    switch (testState.phase) {
      case 'idle':
        return 'Ready to test';
      case 'ping':
        return 'Measuring latency...';
      case 'download':
        return 'Testing download speed...';
      case 'upload':
        return 'Testing upload speed...';
      case 'complete':
        return 'Test complete!';
      case 'error':
        return 'Test failed';
      default:
        return '';
    }
  };
  
  const shareResults = (platform: string) => {
    if (!testResult) return;
    
    const text = `My internet speed: ${testResult.downloadSpeed.toFixed(1)} Mbps download, ${testResult.uploadSpeed.toFixed(1)} Mbps upload! Test yours now.`;
    const url = window.location.origin;
    
    const shareUrls = {
      twitter: `https://twitter.com/intent/tweet?text=${encodeURIComponent(text)}&url=${encodeURIComponent(url)}`,
      facebook: `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(url)}&quote=${encodeURIComponent(text)}`,
      linkedin: `https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(url)}`,
    };
    
    window.open(shareUrls[platform as keyof typeof shareUrls], '_blank', 'width=600,height=400');
  };
  
  return (
    <div className="min-h-screen pt-24 pb-24">
      <div className="max-w-[1400px] mx-auto px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-h1 text-text-primary mb-4">Internet Speed Test</h1>
          <p className="text-large text-text-tertiary">
            Measure your connection speed in real-time
          </p>
        </div>
        
        {/* Test Control Panel */}
        <div className="bg-bg-elevated rounded-lg p-6 border border-border-subtle shadow-card mb-12 text-center">
          <div className="mb-4">
            <p className="text-large text-text-secondary">{getPhaseText()}</p>
          </div>
          
          {testState.phase === 'idle' || testState.phase === 'complete' || testState.phase === 'error' ? (
            <button
              onClick={handleStartTest}
              className="inline-flex items-center gap-2 px-8 py-3 bg-primary-500 text-white text-lg font-semibold rounded-md hover:brightness-110 hover:shadow-glow-button transition-all duration-250"
            >
              <Play className="w-5 h-5" />
              {testState.phase === 'idle' ? 'Start Test' : 'Run Again'}
            </button>
          ) : (
            <div className="flex flex-col items-center gap-4">
              <div className="w-full max-w-md bg-bg-hover rounded-full h-2 overflow-hidden">
                <motion.div
                  className="h-full bg-gradient-to-r from-primary-500 to-accent-green"
                  initial={{ width: '0%' }}
                  animate={{ width: `${testState.progress}%` }}
                  transition={{ duration: 0.3 }}
                />
              </div>
              <p className="text-small text-text-tertiary">{testState.progress.toFixed(0)}% complete</p>
            </div>
          )}
          
          {testState.error && (
            <p className="mt-4 text-error">{testState.error}</p>
          )}
        </div>
        
        {/* Speedometer Gauges */}
        {testState.phase !== 'idle' && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12 mb-12">
            <Speedometer
              value={testState.downloadSpeed}
              maxValue={100}
              label="Download"
              unit="Mbps"
              color="blue"
              isActive={testState.phase === 'download'}
            />
            <Speedometer
              value={testState.uploadSpeed}
              maxValue={100}
              label="Upload"
              unit="Mbps"
              color="green"
              isActive={testState.phase === 'upload'}
            />
            <Speedometer
              value={testState.ping}
              maxValue={200}
              label="Ping"
              unit="ms"
              color="info"
              isActive={testState.phase === 'ping'}
            />
          </div>
        )}
        
        {/* Secondary Metrics */}
        {testResult && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="mb-12"
          >
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
              <div className="bg-bg-elevated p-6 rounded-lg border border-border-subtle">
                <Download className="w-6 h-6 text-primary-500 mb-2" />
                <p className="text-small text-text-tertiary mb-1">Download</p>
                <p className="text-h2 font-mono text-text-primary">{testResult.downloadSpeed.toFixed(1)}</p>
                <p className="text-small text-text-tertiary">Mbps</p>
              </div>
              <div className="bg-bg-elevated p-6 rounded-lg border border-border-subtle">
                <Upload className="w-6 h-6 text-accent-green mb-2" />
                <p className="text-small text-text-tertiary mb-1">Upload</p>
                <p className="text-h2 font-mono text-text-primary">{testResult.uploadSpeed.toFixed(1)}</p>
                <p className="text-small text-text-tertiary">Mbps</p>
              </div>
              <div className="bg-bg-elevated p-6 rounded-lg border border-border-subtle">
                <Activity className="w-6 h-6 text-info mb-2" />
                <p className="text-small text-text-tertiary mb-1">Ping</p>
                <p className="text-h2 font-mono text-text-primary">{testResult.ping.toFixed(0)}</p>
                <p className="text-small text-text-tertiary">ms</p>
              </div>
              <div className="bg-bg-elevated p-6 rounded-lg border border-border-subtle">
                <Activity className="w-6 h-6 text-warning mb-2" />
                <p className="text-small text-text-tertiary mb-1">Jitter</p>
                <p className="text-h2 font-mono text-text-primary">{testResult.jitter.toFixed(1)}</p>
                <p className="text-small text-text-tertiary">ms</p>
              </div>
            </div>
          </motion.div>
        )}
        
        {/* Share Section */}
        {testResult && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5, delay: 0.3 }}
            className="text-center mb-12"
          >
            <h3 className="text-h3 text-text-primary mb-4">Share Your Results</h3>
            <div className="flex justify-center gap-4">
              <button
                onClick={() => shareResults('twitter')}
                className="p-3 bg-bg-elevated border border-border-subtle rounded-md hover:bg-bg-hover hover:border-primary-500 transition-all"
                aria-label="Share on Twitter"
              >
                <Twitter className="w-5 h-5 text-text-secondary" />
              </button>
              <button
                onClick={() => shareResults('facebook')}
                className="p-3 bg-bg-elevated border border-border-subtle rounded-md hover:bg-bg-hover hover:border-primary-500 transition-all"
                aria-label="Share on Facebook"
              >
                <Facebook className="w-5 h-5 text-text-secondary" />
              </button>
              <button
                onClick={() => shareResults('linkedin')}
                className="p-3 bg-bg-elevated border border-border-subtle rounded-md hover:bg-bg-hover hover:border-primary-500 transition-all"
                aria-label="Share on LinkedIn"
              >
                <Linkedin className="w-5 h-5 text-text-secondary" />
              </button>
            </div>
          </motion.div>
        )}
        
        {/* Historical Results */}
        {history.length > 0 && (
          <div className="bg-bg-elevated rounded-lg p-6 border border-border-subtle shadow-card">
            <h3 className="text-h3 text-text-primary mb-4">Recent Tests</h3>
            <div className="overflow-x-auto">
              <table className="w-full text-left">
                <thead className="border-b border-border-subtle">
                  <tr>
                    <th className="pb-3 text-small text-text-tertiary">Date</th>
                    <th className="pb-3 text-small text-text-tertiary">Download</th>
                    <th className="pb-3 text-small text-text-tertiary">Upload</th>
                    <th className="pb-3 text-small text-text-tertiary">Ping</th>
                  </tr>
                </thead>
                <tbody>
                  {history.map((result, index) => (
                    <tr key={index} className="border-b border-border-subtle last:border-0">
                      <td className="py-3 text-base text-text-secondary">
                        {new Date(result.timestamp).toLocaleString()}
                      </td>
                      <td className="py-3 text-base font-mono text-text-primary">
                        {result.downloadSpeed.toFixed(1)} Mbps
                      </td>
                      <td className="py-3 text-base font-mono text-text-primary">
                        {result.uploadSpeed.toFixed(1)} Mbps
                      </td>
                      <td className="py-3 text-base font-mono text-text-primary">
                        {result.ping.toFixed(0)} ms
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
