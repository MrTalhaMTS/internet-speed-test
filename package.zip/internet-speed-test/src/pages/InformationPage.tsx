import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { ChevronDown } from 'lucide-react';

export const InformationPage: React.FC = () => {
  const [openFaq, setOpenFaq] = useState<number | null>(null);
  
  const faqs = [
    {
      question: '¿Qué tan precisa es esta prueba de velocidad?',
      answer: 'Nuestra prueba de velocidad utiliza medición de rendimiento basada en HTTP y WebRTC para detección de latencia, proporcionando resultados precisos para conexiones típicas de hogar y negocio. Los resultados pueden variar según las condiciones de la red, el rendimiento del navegador y la carga del servidor.',
    },
    {
      question: '¿Por qué necesito probar mi velocidad de internet?',
      answer: 'Probar tu velocidad de internet te ayuda a verificar que estás obteniendo las velocidades por las que estás pagando a tu ISP. También puede ayudar a diagnosticar problemas de conexión, determinar si tu red puede manejar actividades que requieren mucho ancho de banda y solucionar problemas de rendimiento.',
    },
    {
      question: '¿Qué significan Mbps, ping y latencia?',
      answer: 'Mbps (megabits por segundo) mide la tasa de transferencia de datos. La velocidad de descarga afecta qué tan rápido recibes datos, mientras que la velocidad de subida afecta qué tan rápido envías datos. El ping mide la latencia (retraso) en milisegundos. La latencia mide la variación en el ping, importante para aplicaciones en tiempo real como videollamadas.',
    },
    {
      question: '¿Qué factores afectan mi velocidad de internet?',
      answer: 'Muchos factores pueden afectar tu velocidad: distancia del router, número de dispositivos conectados, congestión de la red, limitación del ISP, equipos obsoletos, rendimiento del navegador, aplicaciones en segundo plano e incluso la hora del día. Las conexiones WiFi suelen ser más lentas que las conexiones Ethernet por cable.',
    },
    {
      question: '¿Cómo puedo mejorar mi velocidad de internet?',
      answer: 'Prueba estos pasos: acércate al router, usa Ethernet en lugar de WiFi, reinicia el router, cierra aplicaciones innecesarias, actualiza el firmware del router, mejora tu plan de internet o contacta a tu ISP si las velocidades son consistentemente inferiores a lo que pagas.',
    },
    {
      question: '¿Mis datos están privados durante la prueba?',
      answer: 'Sí. Nuestra prueba se ejecuta completamente en tu navegador sin recopilar información personal. No rastreamos tu dirección IP, ubicación o historial de navegación. Los resultados de la prueba se almacenan localmente en tu navegador y nunca se envían a nuestros servidores.',
    },
  ];
  
  return (
    <div className="min-h-screen pt-24 pb-24">
      <div className="max-w-[1400px] mx-auto px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <h1 className="text-h1 text-text-primary mb-4">Cómo Funcionan las Pruebas de Velocidad</h1>
          <p className="text-large text-text-tertiary max-w-3xl mx-auto">
            Aprende sobre la tecnología de prueba de velocidad de internet, métricas y cómo interpretar tus resultados
          </p>
        </div>
        
        {/* Executive Summary */}
        <div className="bg-primary-500/5 border border-primary-500/20 rounded-lg p-8 mb-16">
          <h2 className="text-h2 text-text-primary mb-4">Resumen Ejecutivo</h2>
          <p className="text-base text-text-secondary mb-4">
            Las pruebas de velocidad basadas en navegador son lo suficientemente maduras para ofrecer métricas confiables de descarga, subida y latencia para redes de consumo sin depender de claves API de pago o SDKs propietarios. Nuestra implementación utiliza medición de rendimiento basada en HTTP para velocidades de descarga y subida, combinada con APIs de Navigation Timing y WebRTC para detección de latencia.
          </p>
          <p className="text-base text-text-secondary">
            La prueba opera completamente en tu navegador, garantizando privacidad y eliminando la necesidad de dependencias externas. Los resultados son precisos para conexiones residenciales y comerciales típicas de hasta 1 Gbps.
          </p>
        </div>
        
        {/* Understanding Metrics */}
        <section className="mb-16">
          <h2 className="text-h2 text-text-primary mb-8">Comprensión de las Métricas de Velocidad</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="bg-bg-elevated p-8 rounded-lg border border-border-subtle">
              <h3 className="text-h3 text-text-primary mb-4">Velocidad de Descarga</h3>
              <p className="text-base text-text-secondary mb-4">
                Medida en Mbps (megabits por segundo), la velocidad de descarga indica qué tan rápido fluyen los datos desde internet a tu dispositivo. Esto afecta la calidad del video en streaming, las descargas de archivos y los tiempos de carga de páginas web.
              </p>
              <div className="bg-bg-hover p-4 rounded-md">
                <p className="text-small text-text-tertiary">Casos de uso típicos:</p>
                <ul className="mt-2 space-y-2">
                  <li className="text-small text-text-secondary">• Streaming HD: 5-10 Mbps</li>
                  <li className="text-small text-text-secondary">• Streaming 4K: 25+ Mbps</li>
                  <li className="text-small text-text-secondary">• Juegos en línea: 3-6 Mbps</li>
                  <li className="text-small text-text-secondary">• Videoconferencias: 2-4 Mbps</li>
                </ul>
              </div>
            </div>
            
            <div className="bg-bg-elevated p-8 rounded-lg border border-border-subtle">
              <h3 className="text-h3 text-text-primary mb-4">Velocidad de Subida</h3>
              <p className="text-base text-text-secondary mb-4">
                También medida en Mbps, la velocidad de subida indica qué tan rápido puedes enviar datos desde tu dispositivo a internet. Esto es crucial para videollamadas, copias de seguridad en la nube y compartir archivos.
              </p>
              <div className="bg-bg-hover p-4 rounded-md">
                <p className="text-small text-text-tertiary">Casos de uso típicos:</p>
                <ul className="mt-2 space-y-2">
                  <li className="text-small text-text-secondary">• Videollamadas: 1-3 Mbps</li>
                  <li className="text-small text-text-secondary">• Copias de seguridad en la nube: 5+ Mbps</li>
                  <li className="text-small text-text-secondary">• Transmisión en vivo: 5-10 Mbps</li>
                  <li className="text-small text-text-secondary">• Subida de archivos: varía</li>
                </ul>
              </div>
            </div>
            
            <div className="bg-bg-elevated p-8 rounded-lg border border-border-subtle">
              <h3 className="text-h3 text-text-primary mb-4">Ping (Latencia)</h3>
              <p className="text-base text-text-secondary mb-4">
                Medido en milisegundos (ms), el ping representa el tiempo que tardan los datos en viajar desde tu dispositivo a un servidor y regresar. Valores más bajos son mejores, especialmente para aplicaciones en tiempo real.
              </p>
              <div className="bg-bg-hover p-4 rounded-md">
                <p className="text-small text-text-tertiary">Rangos de rendimiento:</p>
                <ul className="mt-2 space-y-2">
                  <li className="text-small text-text-secondary">• Excelente: Menos de 20ms</li>
                  <li className="text-small text-text-secondary">• Bueno: 20-50ms</li>
                  <li className="text-small text-text-secondary">• Regular: 50-100ms</li>
                  <li className="text-small text-text-secondary">• Pobre: Más de 100ms</li>
                </ul>
              </div>
            </div>
            
            <div className="bg-bg-elevated p-8 rounded-lg border border-border-subtle">
              <h3 className="text-h3 text-text-primary mb-4">Latencia (Jitter)</h3>
              <p className="text-base text-text-secondary mb-4">
                También medida en milisegundos, la latencia representa la variación en el ping a lo largo del tiempo. Una latencia más baja significa una calidad de conexión más consistente, lo cual es importante para llamadas de voz y video.
              </p>
              <div className="bg-bg-hover p-4 rounded-md">
                <p className="text-small text-text-tertiary">Niveles de calidad:</p>
                <ul className="mt-2 space-y-2">
                  <li className="text-small text-text-secondary">• Excelente: Menos de 5ms</li>
                  <li className="text-small text-text-secondary">• Bueno: 5-15ms</li>
                  <li className="text-small text-text-secondary">• Regular: 15-30ms</li>
                  <li className="text-small text-text-secondary">• Pobre: Más de 30ms</li>
                </ul>
              </div>
            </div>
          </div>
        </section>
        
        {/* How the Test Works */}
        <section className="mb-16">
          <h2 className="text-h2 text-text-primary mb-8">Cómo Funciona Nuestra Prueba</h2>
          
          <div className="space-y-6">
            <div className="bg-bg-elevated p-8 rounded-lg border border-border-subtle">
              <h3 className="text-h3 text-text-primary mb-3">1. Medición de Latencia</h3>
              <p className="text-base text-text-secondary">
                Enviamos múltiples solicitudes HTTP pequeñas a servidores de prueba y medimos el tiempo de ida y vuelta usando la API de Performance del navegador. Esto nos da mediciones precisas de ping y latencia sin requerir permisos especiales o plugins.
              </p>
            </div>
            
            <div className="bg-bg-elevated p-8 rounded-lg border border-border-subtle">
              <h3 className="text-h3 text-text-primary mb-3">2. Prueba de Velocidad de Descarga</h3>
              <p className="text-base text-text-secondary">
                Descargamos fragmentos de datos de servidores de prueba usando la API Fetch con streaming habilitado. Al medir el tiempo necesario para recibir cantidades conocidas de datos, calculamos tu velocidad de descarga. Múltiples conexiones y tamaños de transferencia grandes ayudan a minimizar el sesgo de inicio lento de TCP y proporcionar resultados precisos.
              </p>
            </div>
            
            <div className="bg-bg-elevated p-8 rounded-lg border border-border-subtle">
              <h3 className="text-h3 text-text-primary mb-3">3. Prueba de Velocidad de Subida</h3>
              <p className="text-base text-text-secondary">
                Generamos datos aleatorios en tu navegador y los subimos a servidores de prueba usando XMLHttpRequest con monitoreo de progreso. Esto nos permite medir la velocidad de subida con precisión sin requerir almacenamiento de archivos del lado del servidor.
              </p>
            </div>
          </div>
        </section>
        
        {/* Factors Affecting Speed */}
        <section className="mb-16">
          <h2 className="text-h2 text-text-primary mb-8">Factores que Afectan Tu Velocidad</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-bg-elevated p-6 rounded-lg border border-border-subtle">
              <h4 className="text-large font-semibold text-text-primary mb-3">Factores de Red</h4>
              <ul className="space-y-2">
                <li className="text-base text-text-secondary">• Calidad de conexión del ISP y limitación</li>
                <li className="text-base text-text-secondary">• Congestión de red durante horas pico</li>
                <li className="text-base text-text-secondary">• Rendimiento del router y módem</li>
                <li className="text-base text-text-secondary">• Fuerza de señal WiFi e interferencia</li>
              </ul>
            </div>
            
            <div className="bg-bg-elevated p-6 rounded-lg border border-border-subtle">
              <h4 className="text-large font-semibold text-text-primary mb-3">Factores del Dispositivo</h4>
              <ul className="space-y-2">
                <li className="text-base text-text-secondary">• Rendimiento y versión del navegador</li>
                <li className="text-base text-text-secondary">• Carga de CPU de otras aplicaciones</li>
                <li className="text-base text-text-secondary">• Memoria del sistema disponible</li>
                <li className="text-base text-text-secondary">• Capacidades del adaptador de red</li>
              </ul>
            </div>
          </div>
        </section>
        
        {/* FAQ Section */}
        <section>
          <h2 className="text-h2 text-text-primary mb-8">Preguntas Frecuentes</h2>
          
          <div className="space-y-4">
            {faqs.map((faq, index) => (
              <motion.div
                key={index}
                className="bg-bg-elevated rounded-lg border border-border-subtle overflow-hidden"
                initial={false}
              >
                <button
                  onClick={() => setOpenFaq(openFaq === index ? null : index)}
                  className="w-full p-6 text-left flex items-center justify-between hover:bg-bg-hover transition-colors"
                >
                  <h3 className="text-h3 text-text-primary pr-4">{faq.question}</h3>
                  <ChevronDown
                    className={`w-5 h-5 text-text-tertiary transition-transform ${
                      openFaq === index ? 'rotate-180' : ''
                    }`}
                  />
                </button>
                <motion.div
                  initial={false}
                  animate={{
                    height: openFaq === index ? 'auto' : 0,
                    opacity: openFaq === index ? 1 : 0,
                  }}
                  transition={{ duration: 0.3 }}
                  className="overflow-hidden"
                >
                  <div className="px-6 pb-6">
                    <p className="text-base text-text-secondary">{faq.answer}</p>
                  </div>
                </motion.div>
              </motion.div>
            ))}
          </div>
        </section>
      </div>
    </div>
  );
};
