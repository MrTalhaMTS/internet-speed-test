import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Play, Zap, Shield, TrendingUp, Gauge, Activity, Globe, Download, Upload, MapPin, Server, Wifi, Clock, MapPinned, AlertCircle } from 'lucide-react';
import { Speedometer } from '../components/Speedometer';
import { runSpeedTest, SpeedTestState, SpeedTestResult, saveTestResult, getTestHistory } from '../lib/speedTest';

export const HomePage: React.FC = () => {
  const [testState, setTestState] = useState<SpeedTestState>({
    phase: 'idle',
    downloadSpeed: 0,
    uploadSpeed: 0,
    ping: 0,
    jitter: 0,
    progress: 0,
    error: null,
  });
  
  const [testResult, setTestResult] = useState<SpeedTestResult | null>(null);
  const [history, setHistory] = useState<SpeedTestResult[]>(getTestHistory());
  const [locationPermission, setLocationPermission] = useState<'prompt' | 'granted' | 'denied' | 'unsupported'>('prompt');
  const [showLocationInfo, setShowLocationInfo] = useState(false);
  const [isGettingLocation, setIsGettingLocation] = useState(false);
  const [locationStatus, setLocationStatus] = useState<string>('');
  
  // Check location permission status on mount
  useEffect(() => {
    if ('permissions' in navigator) {
      navigator.permissions.query({ name: 'geolocation' as PermissionName }).then((result) => {
        setLocationPermission(result.state as 'prompt' | 'granted' | 'denied');
        result.onchange = () => {
          setLocationPermission(result.state as 'prompt' | 'granted' | 'denied');
        };
      });
    } else if (!('geolocation' in navigator)) {
      setLocationPermission('unsupported');
    }
  }, []);
  
  const handleStartTest = async () => {
    console.log('=== Starting Speed Test ===');
    setTestState({
      phase: 'ping',
      downloadSpeed: 0,
      uploadSpeed: 0,
      ping: 0,
      jitter: 0,
      progress: 0,
      error: null,
    });
    setTestResult(null);
    setIsGettingLocation(true);
    setLocationStatus('Iniciando...');
    
    try {
      const result = await runSpeedTest(
        (update) => {
          setTestState((prev) => ({ ...prev, ...update }));
          
          // Stop showing "getting location" once we've moved past the initial phase
          if (update.phase === 'ping' || update.phase === 'download') {
            setIsGettingLocation(false);
          }
        },
        (locationUpdate) => {
          setLocationStatus(locationUpdate);
          console.log('Location update:', locationUpdate);
        }
      );
      
      console.log('Test completed successfully:', result);
      setTestResult(result);
      saveTestResult(result);
      setHistory(getTestHistory());
      setIsGettingLocation(false);
    } catch (error) {
      console.error('Test failed:', error);
      setIsGettingLocation(false);
      setLocationStatus('Error al obtener ubicación');
    }
  };
  
  const getPhaseText = () => {
    switch (testState.phase) {
      case 'idle':
        return 'Listo para probar';
      case 'ping':
        return 'Midiendo latencia...';
      case 'download':
        return 'Probando velocidad de descarga...';
      case 'upload':
        return 'Probando velocidad de subida...';
      case 'complete':
        return '¡Prueba completada!';
      case 'error':
        return 'Prueba fallida';
      default:
        return '';
    }
  };
  
  const features = [
    {
      icon: <Zap className="w-8 h-8" />,
      title: 'Rápido como un Rayo',
      description: 'Obtén resultados precisos en segundos con nuestro motor de pruebas optimizado.',
    },
    {
      icon: <Shield className="w-8 h-8" />,
      title: 'Privacidad Primero',
      description: 'Sin registro, sin seguimiento. Tus datos permanecen privados y seguros.',
    },
    {
      icon: <TrendingUp className="w-8 h-8" />,
      title: 'Resultados en Tiempo Real',
      description: 'Observa tus métricas de descarga, subida y ping actualizándose en tiempo real.',
    },
  ];
  
  const isTesting = testState.phase !== 'idle' && testState.phase !== 'complete' && testState.phase !== 'error';
  
  return (
    <div className="min-h-screen">
      {/* Hero Section with Integrated Speed Test */}
      <section className="relative pt-24 pb-16 flex items-center justify-center bg-gradient-radial from-primary-500/5 to-bg-base">
        <div className="max-w-[1400px] mx-auto px-8 w-full">
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-hero text-text-primary mb-6 text-center"
          >
            Prueba tu Velocidad de Internet
          </motion.h1>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="text-large text-text-tertiary mb-12 max-w-2xl mx-auto text-center"
          >
            Prueba precisa, gratuita e instantánea. No se requiere cuenta. Prueba tu conexión en segundos.
          </motion.p>
          
          {/* Test Control Panel */}
          <div className="bg-bg-elevated rounded-lg p-6 border border-border-subtle shadow-card mb-12 text-center max-w-2xl mx-auto">
            <div className="mb-4">
              <div className="flex items-center justify-center gap-3">
                {isGettingLocation && (
                  <div className="w-5 h-5 border-2 border-primary-500 border-t-transparent rounded-full animate-spin" />
                )}
                <p className="text-large text-text-secondary">
                  {isGettingLocation ? 'Obteniendo tu ubicación...' : getPhaseText()}
                </p>
              </div>
            </div>
            
            {/* Location Permission Info */}
            {locationPermission === 'prompt' && testState.phase === 'idle' && (
              <motion.div
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                className="mb-4 p-4 bg-info/10 border border-info/30 rounded-md"
              >
                <div className="flex items-start gap-3">
                  <MapPinned className="w-5 h-5 text-info mt-0.5" />
                  <div className="flex-1">
                    <p className="text-base text-text-primary font-medium mb-1">
                      Permitir acceso a ubicación para resultados más precisos
                    </p>
                    <p className="text-small text-text-secondary">
                      Usaremos tu ubicación para seleccionar el servidor más cercano y mostrarte la distancia exacta.
                    </p>
                    <button
                      onClick={() => setShowLocationInfo(!showLocationInfo)}
                      className="text-small text-info hover:underline mt-2"
                    >
                      {showLocationInfo ? 'Ocultar detalles' : '¿Por qué necesitamos esto?'}
                    </button>
                    {showLocationInfo && (
                      <motion.div
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: 'auto' }}
                        className="mt-3 text-small text-text-secondary space-y-2"
                      >
                        <p>• <strong>Servidor óptimo:</strong> Seleccionamos el servidor de prueba más cercano</p>
                        <p>• <strong>Distancia exacta:</strong> Calculamos la distancia real entre tu ubicación y el servidor</p>
                        <p>• <strong>Privacidad:</strong> La ubicación solo se usa durante la prueba y no se guarda en ningún servidor</p>
                        <p className="text-text-tertiary italic mt-2">
                          Si no permites el acceso, usaremos tu dirección IP para aproximar la ubicación.
                        </p>
                      </motion.div>
                    )}
                  </div>
                </div>
              </motion.div>
            )}
            
            {locationPermission === 'denied' && testState.phase === 'idle' && (
              <motion.div
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                className="mb-4 p-4 bg-warning/10 border border-warning/30 rounded-md"
              >
                <div className="flex items-start gap-3">
                  <AlertCircle className="w-5 h-5 text-warning mt-0.5" />
                  <div className="flex-1">
                    <p className="text-base text-text-primary font-medium mb-1">
                      Ubicación denegada
                    </p>
                    <p className="text-small text-text-secondary">
                      Usaremos tu dirección IP para aproximar la ubicación. Para mayor precisión, permite el acceso a la ubicación en la configuración del navegador.
                    </p>
                  </div>
                </div>
              </motion.div>
            )}
            
            {/* Location Status Display - Shows real-time location detection progress */}
            {(isGettingLocation || locationStatus) && (
              <motion.div
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                className="mb-4 p-4 bg-primary-500/10 border border-primary-500/30 rounded-md"
              >
                <div className="flex items-center gap-3">
                  <MapPin className="w-5 h-5 text-primary-500" />
                  <div className="flex-1">
                    <p className="text-base text-text-primary font-medium">
                      {locationStatus || 'Detectando ubicación...'}
                    </p>
                  </div>
                  {isGettingLocation && (
                    <div className="w-5 h-5 border-2 border-primary-500 border-t-transparent rounded-full animate-spin" />
                  )}
                </div>
              </motion.div>
            )}
            
            {!isTesting ? (
              <button
                onClick={handleStartTest}
                className="inline-flex items-center gap-2 px-8 py-3 bg-primary-500 text-white text-lg font-semibold rounded-md hover:brightness-110 hover:shadow-glow-button transition-all duration-250"
              >
                <Play className="w-5 h-5" />
                {testState.phase === 'idle' ? 'Iniciar Prueba' : 'Probar de Nuevo'}
              </button>
            ) : (
              <div className="flex flex-col items-center gap-4">
                <div className="w-full max-w-md bg-bg-hover rounded-full h-2 overflow-hidden">
                  <motion.div
                    className="h-full bg-gradient-to-r from-primary-500 to-accent-green"
                    initial={{ width: '0%' }}
                    animate={{ width: `${testState.progress}%` }}
                    transition={{ duration: 0.3 }}
                  />
                </div>
                <p className="text-small text-text-tertiary">{testState.progress.toFixed(0)}% completado</p>
              </div>
            )}
            
            {testState.error && (
              <p className="mt-4 text-error">{testState.error}</p>
            )}
          </div>
          
          {/* Speedometer Gauges */}
          {testState.phase !== 'idle' && (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-12 mb-12">
              <Speedometer
                value={testState.downloadSpeed}
                maxValue={100}
                label="Descarga"
                unit="Mbps"
                color="blue"
                isActive={testState.phase === 'download'}
              />
              <Speedometer
                value={testState.uploadSpeed}
                maxValue={100}
                label="Subida"
                unit="Mbps"
                color="green"
                isActive={testState.phase === 'upload'}
              />
              <Speedometer
                value={testState.ping}
                maxValue={200}
                label="Ping"
                unit="ms"
                color="info"
                isActive={testState.phase === 'ping'}
              />
            </div>
          )}
          
          {/* Test Results - Primary Metrics */}
          {testResult && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="mb-12"
            >
              <h3 className="text-h3 text-text-primary mb-6 text-center">Resultados de la Prueba</h3>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-8">
                <div className="bg-bg-elevated p-6 rounded-lg border border-border-subtle">
                  <Download className="w-6 h-6 text-primary-500 mb-2" />
                  <p className="text-small text-text-tertiary mb-1">Velocidad de Descarga</p>
                  <p className="text-h2 font-mono text-text-primary">{testResult.downloadSpeed.toFixed(1)}</p>
                  <p className="text-small text-text-tertiary">Mbps</p>
                </div>
                <div className="bg-bg-elevated p-6 rounded-lg border border-border-subtle">
                  <Upload className="w-6 h-6 text-accent-green mb-2" />
                  <p className="text-small text-text-tertiary mb-1">Velocidad de Subida</p>
                  <p className="text-h2 font-mono text-text-primary">{testResult.uploadSpeed.toFixed(1)}</p>
                  <p className="text-small text-text-tertiary">Mbps</p>
                </div>
                <div className="bg-bg-elevated p-6 rounded-lg border border-border-subtle">
                  <Activity className="w-6 h-6 text-info mb-2" />
                  <p className="text-small text-text-tertiary mb-1">Ping</p>
                  <p className="text-h2 font-mono text-text-primary">{testResult.ping.toFixed(0)}</p>
                  <p className="text-small text-text-tertiary">ms</p>
                </div>
                <div className="bg-bg-elevated p-6 rounded-lg border border-border-subtle">
                  <Activity className="w-6 h-6 text-warning mb-2" />
                  <p className="text-small text-text-tertiary mb-1">Latencia</p>
                  <p className="text-h2 font-mono text-text-primary">{testResult.jitter.toFixed(1)}</p>
                  <p className="text-small text-text-tertiary">ms</p>
                </div>
              </div>
              
              {/* Enriched Metadata */}
              <div className="bg-bg-elevated rounded-lg p-6 border border-border-subtle">
                <h4 className="text-h4 text-text-primary mb-6">Detalles de la Conexión</h4>
                
                {/* Prominent Location Display */}
                <div className="mb-6 p-4 bg-primary-500/5 border border-primary-500/20 rounded-lg">
                  <div className="flex items-center gap-3 mb-2">
                    <MapPin className="w-6 h-6 text-primary-500" />
                    <p className="text-base text-text-tertiary font-medium">Tu Ubicación</p>
                  </div>
                  <p className={`text-xl font-semibold ${
                    testResult.userLocation.includes('Unknown') 
                      ? 'text-warning' 
                      : 'text-text-primary'
                  }`}>
                    {testResult.userLocation}
                  </p>
                  {testResult.userLocation.includes('Unknown') && (
                    <p className="text-small text-warning mt-1">
                      ⚠ No se pudo determinar tu ubicación exacta
                    </p>
                  )}
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="flex items-start gap-3">
                    <Wifi className="w-5 h-5 text-primary-500 mt-1" />
                    <div>
                      <p className="text-small text-text-tertiary">Proveedor de Internet (ISP)</p>
                      <p className="text-base text-text-primary font-medium">{testResult.isp}</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <Globe className="w-5 h-5 text-primary-500 mt-1" />
                    <div>
                      <p className="text-small text-text-tertiary">Dirección IP</p>
                      <p className="text-base text-text-primary font-mono">{testResult.ipAddress}</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <Activity className="w-5 h-5 text-primary-500 mt-1" />
                    <div>
                      <p className="text-small text-text-tertiary">Número ASN</p>
                      <p className="text-base text-text-primary font-mono">{testResult.asn}</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <Server className="w-5 h-5 text-primary-500 mt-1" />
                    <div>
                      <p className="text-small text-text-tertiary">Servidor</p>
                      <p className="text-base text-text-primary">{testResult.serverName} - {testResult.serverLocation}</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <MapPin className="w-5 h-5 text-primary-500 mt-1" />
                    <div>
                      <p className="text-small text-text-tertiary">Distancia</p>
                      <p className="text-base text-text-primary">{testResult.serverDistance} km</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <Clock className="w-5 h-5 text-primary-500 mt-1" />
                    <div>
                      <p className="text-small text-text-tertiary">Hora de la Prueba</p>
                      <p className="text-base text-text-primary">{new Date(testResult.timestamp).toLocaleString('es-ES')}</p>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          )}
        </div>
      </section>
      
      {/* Features Section */}
      <section className="py-24 max-w-[1400px] mx-auto px-8">
        <h2 className="text-h2 text-text-primary text-center mb-16">¿Por Qué Elegir Nuestra Prueba de Velocidad?</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              viewport={{ once: true }}
              className="bg-bg-elevated p-8 rounded-lg border border-border-subtle shadow-card hover:bg-bg-hover transition-all duration-250"
            >
              <div className="text-primary-500 mb-4">{feature.icon}</div>
              <h3 className="text-h3 text-text-primary mb-3">{feature.title}</h3>
              <p className="text-base text-text-secondary">{feature.description}</p>
            </motion.div>
          ))}
        </div>
      </section>
      
      {/* How It Works Section */}
      <section className="py-24 bg-bg-elevated/50">
        <div className="max-w-[1400px] mx-auto px-8">
          <h2 className="text-h2 text-text-primary text-center mb-16">Cómo Funciona</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
            {[
              {
                icon: <Gauge className="w-12 h-12" />,
                title: 'Haz Clic en Prueba',
                description: 'Inicia la prueba de velocidad con un solo clic',
              },
              {
                icon: <Activity className="w-12 h-12" />,
                title: 'Mide la Velocidad',
                description: 'Probamos tu descarga, subida y latencia',
              },
              {
                icon: <Globe className="w-12 h-12" />,
                title: 'Ver Resultados',
                description: 'Obtén métricas detalladas y comparaciones',
              },
            ].map((step, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                viewport={{ once: true }}
                className="text-center"
              >
                <div className="inline-flex items-center justify-center w-24 h-24 rounded-full bg-primary-500/10 text-primary-500 mb-6">
                  {step.icon}
                </div>
                <h3 className="text-h3 text-text-primary mb-3">{step.title}</h3>
                <p className="text-base text-text-secondary">{step.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>
      
      {/* Technology Brief Section */}
      <section className="py-24 max-w-[1200px] mx-auto px-8">
        <div className="grid grid-cols-1 md:grid-cols-7 gap-12 items-center">
          <div className="md:col-span-4">
            <h2 className="text-h2 text-text-primary mb-6">Tecnología Avanzada</h2>
            <p className="text-base text-text-secondary mb-4">
              Nuestra prueba de velocidad utiliza métodos de prueba avanzados basados en el navegador para ofrecer mediciones precisas de tu conexión a internet. Usando medición de rendimiento basada en HTTP y WebRTC para detección de latencia, proporcionamos información completa sobre el rendimiento de tu red.
            </p>
            <p className="text-base text-text-secondary">
              No se requieren claves API ni dependencias externas. Todo se ejecuta localmente en tu navegador para máxima privacidad y seguridad.
            </p>
          </div>
          <div className="md:col-span-3">
            <div className="bg-bg-elevated p-8 rounded-lg border border-border-subtle shadow-card">
              <h3 className="text-h3 text-text-primary mb-4">Características Clave</h3>
              <ul className="space-y-3">
                <li className="flex items-start gap-3">
                  <div className="w-2 h-2 rounded-full bg-primary-500 mt-2" />
                  <span className="text-base text-text-secondary">Medición de rendimiento basada en HTTP</span>
                </li>
                <li className="flex items-start gap-3">
                  <div className="w-2 h-2 rounded-full bg-primary-500 mt-2" />
                  <span className="text-base text-text-secondary">Web Workers para precisión</span>
                </li>
                <li className="flex items-start gap-3">
                  <div className="w-2 h-2 rounded-full bg-primary-500 mt-2" />
                  <span className="text-base text-text-secondary">Visualización de métricas en tiempo real</span>
                </li>
                <li className="flex items-start gap-3">
                  <div className="w-2 h-2 rounded-full bg-primary-500 mt-2" />
                  <span className="text-base text-text-secondary">Diseño que prioriza la privacidad</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>
      
      {/* Historical Results */}
      {history.length > 0 && (
        <section className="py-24 bg-bg-elevated/50">
          <div className="max-w-[1400px] mx-auto px-8">
            <div className="bg-bg-elevated rounded-lg p-6 border border-border-subtle shadow-card">
              <h3 className="text-h3 text-text-primary mb-4">Pruebas Recientes</h3>
              <div className="overflow-x-auto">
                <table className="w-full text-left">
                  <thead className="border-b border-border-subtle">
                    <tr>
                      <th className="pb-3 text-small text-text-tertiary">Fecha</th>
                      <th className="pb-3 text-small text-text-tertiary">Descarga</th>
                      <th className="pb-3 text-small text-text-tertiary">Subida</th>
                      <th className="pb-3 text-small text-text-tertiary">Ping</th>
                    </tr>
                  </thead>
                  <tbody>
                    {history.map((result, index) => (
                      <tr key={index} className="border-b border-border-subtle last:border-0">
                        <td className="py-3 text-base text-text-secondary">
                          {new Date(result.timestamp).toLocaleString('es-ES')}
                        </td>
                        <td className="py-3 text-base font-mono text-text-primary">
                          {result.downloadSpeed.toFixed(1)} Mbps
                        </td>
                        <td className="py-3 text-base font-mono text-text-primary">
                          {result.uploadSpeed.toFixed(1)} Mbps
                        </td>
                        <td className="py-3 text-base font-mono text-text-primary">
                          {result.ping.toFixed(0)} ms
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </section>
      )}
    </div>
  );
};
