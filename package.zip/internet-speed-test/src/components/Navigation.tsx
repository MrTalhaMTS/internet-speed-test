import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

export const Navigation: React.FC = () => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const location = useLocation();
  
  const navLinks = [
    { path: '/', label: 'Inicio' },
    { path: '/information', label: 'Información' },
    { path: '/contact', label: 'Contacto' },
    { path: '/privacy', label: 'Política de Privacidad' },
  ];
  
  const isActive = (path: string) => location.pathname === path;
  
  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-bg-base/90 backdrop-blur-xl border-b border-border-subtle">
      <div className="max-w-[1400px] mx-auto px-8 h-16 flex items-center justify-between">
        {/* Logo */}
        <Link to="/" className="flex items-center gap-2 text-text-primary hover:text-primary-500 transition-colors">
          <svg className="w-8 h-8" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
            <circle cx="16" cy="16" r="14" stroke="currentColor" strokeWidth="2" fill="none" />
            <path d="M16 8 L16 16 L22 20" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
            <circle cx="16" cy="16" r="2" fill="currentColor" />
          </svg>
          <span className="text-lg font-semibold">SpeedTest</span>
        </Link>
        
        {/* Desktop Navigation */}
        <div className="hidden md:flex items-center gap-8">
          {navLinks.map((link) => (
            <Link
              key={link.path}
              to={link.path}
              className={`relative text-base transition-colors ${
                isActive(link.path) ? 'text-text-primary' : 'text-text-tertiary hover:text-text-primary'
              }`}
            >
              {link.label}
              {isActive(link.path) && (
                <motion.div
                  layoutId="underline"
                  className="absolute -bottom-[22px] left-0 right-0 h-0.5 bg-primary-500"
                />
              )}
            </Link>
          ))}
        </div>
        
        {/* CTA Button (Desktop) */}
        <a
          href="#test"
          onClick={(e) => {
            if (location.pathname === '/') {
              e.preventDefault();
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }
          }}
          className="hidden md:block px-6 py-2 bg-primary-500 text-white rounded-md font-semibold hover:brightness-110 hover:shadow-glow-button transition-all duration-250"
        >
          Iniciar Prueba
        </a>
        
        {/* Mobile Menu Button */}
        <button
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          className="md:hidden p-2 text-text-primary hover:text-primary-500 transition-colors"
          aria-label="Toggle menu"
        >
          {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
        </button>
      </div>
      
      {/* Mobile Menu */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden bg-bg-modal border-t border-border-subtle overflow-hidden"
          >
            <div className="px-8 py-6 flex flex-col gap-6">
              {navLinks.map((link) => (
                <Link
                  key={link.path}
                  to={link.path}
                  onClick={() => setMobileMenuOpen(false)}
                  className={`text-base ${
                    isActive(link.path) ? 'text-text-primary font-semibold' : 'text-text-tertiary'
                  }`}
                >
                  {link.label}
                </Link>
              ))}
              <a
                href="#test"
                onClick={(e) => {
                  setMobileMenuOpen(false);
                  if (location.pathname === '/') {
                    e.preventDefault();
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }
                }}
                className="px-6 py-3 bg-primary-500 text-white rounded-md font-semibold text-center hover:brightness-110 transition-all"
              >
                Iniciar Prueba
              </a>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
};
