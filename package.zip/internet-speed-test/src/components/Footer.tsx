import React from 'react';

export const Footer: React.FC = () => {
  const currentYear = new Date().getFullYear();
  
  return (
    <footer className="bg-bg-base border-t border-border-subtle mt-24">
      <div className="max-w-[1400px] mx-auto px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
          {/* About */}
          <div>
            <h3 className="text-h3 text-text-primary mb-4">Acerca de</h3>
            <p className="text-base text-text-secondary">
              Pruebas de velocidad de internet gratuitas, rápidas y precisas para todos. No se requiere registro.
            </p>
          </div>
          
          {/* Quick Links */}
          <div>
            <h3 className="text-h3 text-text-primary mb-4">Enlaces Rápidos</h3>
            <ul className="space-y-2">
              <li>
                <a href="/" className="text-base text-text-tertiary hover:text-primary-500 transition-colors">
                  Inicio
                </a>
              </li>
              <li>
                <a href="/information" className="text-base text-text-tertiary hover:text-primary-500 transition-colors">
                  Información
                </a>
              </li>
              <li>
                <a href="/contact" className="text-base text-text-tertiary hover:text-primary-500 transition-colors">
                  Contacto
                </a>
              </li>
            </ul>
          </div>
          
          {/* Legal */}
          <div>
            <h3 className="text-h3 text-text-primary mb-4">Legal</h3>
            <ul className="space-y-2">
              <li>
                <a href="/privacy" className="text-base text-text-tertiary hover:text-primary-500 transition-colors">
                  Política de Privacidad
                </a>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="mt-12 pt-8 border-t border-border-subtle text-center">
          <p className="text-small text-text-tertiary">
            {currentYear} Prueba de Velocidad de Internet. Todos los derechos reservados.
          </p>
        </div>
      </div>
    </footer>
  );
};
