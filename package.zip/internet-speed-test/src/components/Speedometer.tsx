import React, { useEffect, useState } from 'react';
import { motion, useSpring, useTransform } from 'framer-motion';

interface SpeedometerProps {
  value: number;
  maxValue: number;
  label: string;
  unit: string;
  color?: 'blue' | 'green' | 'info';
  isActive?: boolean;
}

export const Speedometer: React.FC<SpeedometerProps> = ({
  value,
  maxValue,
  label,
  unit,
  color = 'blue',
  isActive = false,
}) => {
  // Use Framer Motion's spring for smooth, physics-based animation
  const springValue = useSpring(0, {
    stiffness: 80,
    damping: 15,
    mass: 0.5,
  });
  
  // Animated display value for the text
  const [displayValue, setDisplayValue] = useState(0);
  
  // Update spring value when prop changes
  useEffect(() => {
    springValue.set(value);
  }, [value, springValue]);
  
  // Smooth animation for display text
  useEffect(() => {
    const unsubscribe = springValue.on('change', (latest) => {
      setDisplayValue(latest);
    });
    return () => unsubscribe();
  }, [springValue]);
  
  // Calculate needle rotation (0-180 degrees) from spring value
  const rotation = useTransform(springValue, [0, maxValue], [-90, 90]);
  
  // Color configurations
  const colors = {
    blue: {
      gradient: ['#007AFF', '#409CFF'],
      glow: 'rgba(0, 122, 255, 0.4)',
    },
    green: {
      gradient: ['#32D74B', '#5FDC68'],
      glow: 'rgba(50, 215, 75, 0.4)',
    },
    info: {
      gradient: ['#64D2FF', '#8EDCFF'],
      glow: 'rgba(100, 210, 255, 0.4)',
    },
  };
  
  const colorConfig = colors[color];
  
  return (
    <div className="flex flex-col items-center">
      <h3 className="text-h3 mb-6 text-text-primary">{label}</h3>
      
      <div className="relative w-[280px] h-[280px] md:w-[280px] md:h-[280px] sm:w-[220px] sm:h-[220px]">
        {/* Gauge container */}
        <div
          className="absolute inset-0 rounded-full bg-bg-elevated border-2 border-border-default shadow-card"
          style={{
            boxShadow: isActive ? `0 0 16px ${colorConfig.glow}` : undefined,
          }}
        >
          {/* Background arc */}
          <svg className="absolute inset-0 w-full h-full" viewBox="0 0 200 200">
            <defs>
              <linearGradient id={`gradient-${color}`} x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%" stopColor={colorConfig.gradient[0]} />
                <stop offset="100%" stopColor={colorConfig.gradient[1]} />
              </linearGradient>
            </defs>
            
            {/* Background arc */}
            <path
              d="M 30 170 A 80 80 0 0 1 170 170"
              fill="none"
              stroke="#21262D"
              strokeWidth="20"
              strokeLinecap="round"
            />
            
            {/* Progress arc */}
            <motion.path
              d="M 30 170 A 80 80 0 0 1 170 170"
              fill="none"
              stroke={`url(#gradient-${color})`}
              strokeWidth="20"
              strokeLinecap="round"
              strokeDasharray="251.2"
              strokeDashoffset={useTransform(springValue, [0, maxValue], [251.2, 0])}
            />
            
            {/* Needle */}
            <motion.g
              style={{ 
                rotate: rotation,
                transformOrigin: '100px 100px',
              }}
            >
              <line
                x1="100"
                y1="100"
                x2="100"
                y2="30"
                stroke="#FFFFFF"
                strokeWidth="2"
                strokeLinecap="round"
                style={{
                  filter: isActive ? `drop-shadow(0 0 6px ${colorConfig.glow})` : undefined,
                }}
              />
              <circle cx="100" cy="100" r="6" fill="#FFFFFF" />
            </motion.g>
          </svg>
          
          {/* Center metric display */}
          <div className="absolute inset-0 flex flex-col items-center justify-center mt-8">
            <div className="text-metric font-mono text-text-primary">
              {displayValue.toFixed(1)}
            </div>
            <div className="text-small text-text-tertiary mt-2">{unit}</div>
          </div>
          
          {/* Min/Max labels */}
          <div className="absolute bottom-8 left-8 text-small text-text-tertiary">0</div>
          <div className="absolute bottom-8 right-8 text-small text-text-tertiary">{maxValue}</div>
        </div>
      </div>
    </div>
  );
};
