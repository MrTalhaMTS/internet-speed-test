// Speed test configuration
export const TEST_CONFIG = {
  // Test file sizes in bytes
  DOWNLOAD_SIZE: 25 * 1024 * 1024, // 25MB
  UPLOAD_SIZE: 5 * 1024 * 1024, // 5MB
  // Test duration limits
  TEST_DURATION: 10000, // 10 seconds
  // Progress update interval
  UPDATE_INTERVAL: 100, // 100ms
  // Number of parallel connections
  PARALLEL_CONNECTIONS: 4,
  // Test servers (using public test endpoints)
  TEST_SERVERS: [
    {
      name: 'CloudFlare',
      url: 'https://speed.cloudflare.com/__down?bytes=',
      uploadUrl: 'https://speed.cloudflare.com/__up',
      lat: 37.7749, // San Francisco (CloudFlare HQ)
      lon: -122.4194,
      location: 'San Francisco, CA, USA',
    },
  ] as TestServer[],
  // Alternative upload endpoints (fallbacks)
  ALTERNATIVE_UPLOAD_URLS: [
    'https://speed.cloudflare.com/__up',
    // Add more if needed
  ],
};

// Geo location data interface
export interface GeoLocationData {
  ip: string;
  city: string;
  region: string;
  country: string;
  isp: string;
  asn: string;
  lat: number;
  lon: number;
}

// Test server with location
export interface TestServer {
  name: string;
  url: string;
  uploadUrl: string;
  lat: number;
  lon: number;
  location: string;
}

// Speed test results interface
export interface SpeedTestResult {
  downloadSpeed: number; // Mbps
  uploadSpeed: number; // Mbps
  ping: number; // ms
  jitter: number; // ms
  serverName: string;
  serverLocation: string;
  serverDistance: number; // km
  ipAddress: string;
  isp: string;
  asn: string;
  userLocation: string; // "City, Region, Country"
  timestamp: Date;
}

// Speed test state
export type TestPhase = 'idle' | 'ping' | 'download' | 'upload' | 'complete' | 'error';

export interface SpeedTestState {
  phase: TestPhase;
  downloadSpeed: number;
  uploadSpeed: number;
  ping: number;
  jitter: number;
  progress: number;
  error: string | null;
}

// Measure latency using HTTP timing
async function measureLatency(url: string, samples: number = 5): Promise<{ ping: number; jitter: number }> {
  const latencies: number[] = [];
  
  for (let i = 0; i < samples; i++) {
    const start = performance.now();
    try {
      await fetch(url + '1024', { // Small 1KB request
        method: 'GET',
        cache: 'no-store',
      });
      const end = performance.now();
      latencies.push(end - start);
    } catch (error) {
      console.error('Latency measurement error:', error);
    }
    
    // Wait a bit between samples
    if (i < samples - 1) {
      await new Promise(resolve => setTimeout(resolve, 100));
    }
  }
  
  if (latencies.length === 0) {
    return { ping: 0, jitter: 0 };
  }
  
  // Calculate average latency (ping)
  const ping = latencies.reduce((a, b) => a + b, 0) / latencies.length;
  
  // Calculate jitter (variation in latency)
  const jitter = latencies.length > 1
    ? Math.sqrt(
        latencies
          .map(l => Math.pow(l - ping, 2))
          .reduce((a, b) => a + b, 0) / latencies.length
      )
    : 0;
  
  return { ping, jitter };
}

// Measure download speed
async function measureDownloadSpeed(
  url: string,
  size: number,
  onProgress: (speed: number) => void
): Promise<number> {
  const startTime = performance.now();
  let lastUpdate = startTime;
  let downloadedBytes = 0;
  let maxSpeed = 0;
  
  try {
    const response = await fetch(url + size, {
      method: 'GET',
      cache: 'no-store',
    });
    
    if (!response.body) {
      throw new Error('Response body is null');
    }
    
    const reader = response.body.getReader();
    
    while (true) {
      const { done, value } = await reader.read();
      
      if (done) break;
      
      downloadedBytes += value.length;
      const currentTime = performance.now();
      
      // Update speed every UPDATE_INTERVAL ms
      if (currentTime - lastUpdate >= TEST_CONFIG.UPDATE_INTERVAL) {
        const elapsed = (currentTime - startTime) / 1000; // seconds
        const speed = (downloadedBytes * 8) / (elapsed * 1000000); // Mbps
        maxSpeed = Math.max(maxSpeed, speed);
        onProgress(speed);
        lastUpdate = currentTime;
      }
      
      // Stop if test duration exceeded
      if (currentTime - startTime >= TEST_CONFIG.TEST_DURATION) {
        break;
      }
    }
    
    const totalTime = (performance.now() - startTime) / 1000; // seconds
    const finalSpeed = (downloadedBytes * 8) / (totalTime * 1000000); // Mbps
    
    return Math.max(maxSpeed, finalSpeed);
  } catch (error) {
    console.error('Download test error:', error);
    throw error;
  }
}

// Measure upload speed with Fetch API fallback
async function measureUploadSpeed(
  url: string,
  size: number,
  onProgress: (speed: number) => void
): Promise<number> {
  console.log('Starting upload test with size:', size);
  
  // Try XHR first (best for progress tracking)
  try {
    return await measureUploadWithXHR(url, size, onProgress);
  } catch (xhrError) {
    console.warn('XHR upload failed, trying Fetch API:', xhrError);
    // Fallback to Fetch API
    try {
      return await measureUploadWithFetch(url, size, onProgress);
    } catch (fetchError) {
      console.error('Both XHR and Fetch upload methods failed:', fetchError);
      throw fetchError;
    }
  }
}

// Upload using XMLHttpRequest (preferred for progress tracking)
async function measureUploadWithXHR(
  url: string,
  size: number,
  onProgress: (speed: number) => void
): Promise<number> {
  return new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    let startTime: number = 0;
    let uploadedBytes = 0;
    let maxSpeed = 0;
    let lastUpdate = 0;
    let progressReported = false;
    
    // Generate random upload data
    const uploadData = new Uint8Array(size);
    try {
      crypto.getRandomValues(uploadData);
    } catch (e) {
      for (let i = 0; i < size; i++) {
        uploadData[i] = Math.floor(Math.random() * 256);
      }
    }
    
    console.log('[XHR] Upload data generated, size:', uploadData.length);
    
    xhr.timeout = 30000; // 30 seconds
    
    // Track upload start
    xhr.upload.addEventListener('loadstart', () => {
      startTime = performance.now();
      lastUpdate = startTime;
      console.log('[XHR] Upload started at', startTime);
    });
    
    // Track upload progress
    xhr.upload.addEventListener('progress', (event) => {
      if (event.lengthComputable) {
        progressReported = true;
        uploadedBytes = event.loaded;
        const currentTime = performance.now();
        
        if (currentTime - lastUpdate >= TEST_CONFIG.UPDATE_INTERVAL) {
          const elapsed = (currentTime - startTime) / 1000;
          if (elapsed > 0) {
            const speed = (uploadedBytes * 8) / (elapsed * 1000000);
            maxSpeed = Math.max(maxSpeed, speed);
            onProgress(speed);
            lastUpdate = currentTime;
            console.log('[XHR] Progress:', uploadedBytes, 'bytes,', speed.toFixed(2), 'Mbps');
          }
        }
      }
    });
    
    // Upload complete
    xhr.upload.addEventListener('load', () => {
      console.log('[XHR] Upload load event');
      if (!startTime) startTime = performance.now() - 1000; // Fallback
    });
    
    // Request completed
    xhr.addEventListener('load', () => {
      console.log('[XHR] Request complete, status:', xhr.status);
      
      if (xhr.status >= 200 && xhr.status < 400) {
        const endTime = performance.now();
        const durationS = (endTime - startTime) / 1000;
        
        if (durationS > 0 && startTime > 0) {
          const finalBytes = uploadedBytes > 0 ? uploadedBytes : size;
          const speedMbps = (finalBytes * 8) / durationS / 1_000_000;
          const resultSpeed = Math.max(maxSpeed, speedMbps);
          
          console.log('[XHR] Upload SUCCESS:', {
            bytes: finalBytes,
            duration: durationS.toFixed(2),
            speed: resultSpeed.toFixed(2)
          });
          
          onProgress(resultSpeed);
          resolve(resultSpeed);
        } else {
          const finalSpeed = maxSpeed > 0 ? maxSpeed : 0;
          onProgress(finalSpeed);
          resolve(finalSpeed);
        }
      } else {
        console.warn('[XHR] Non-success status:', xhr.status);
        if (progressReported && maxSpeed > 0) {
          onProgress(maxSpeed);
          resolve(maxSpeed);
        } else {
          reject(new Error(`Upload failed: HTTP ${xhr.status}`));
        }
      }
    });
    
    xhr.addEventListener('error', () => {
      console.error('[XHR] Network error');
      if (progressReported && maxSpeed > 0) {
        onProgress(maxSpeed);
        resolve(maxSpeed);
      } else {
        reject(new Error('XHR network error'));
      }
    });
    
    xhr.addEventListener('timeout', () => {
      console.error('[XHR] Timeout');
      if (progressReported && maxSpeed > 0) {
        onProgress(maxSpeed);
        resolve(maxSpeed);
      } else {
        reject(new Error('XHR timeout'));
      }
    });
    
    try {
      xhr.open('POST', url, true);
      xhr.setRequestHeader('Content-Type', 'application/octet-stream');
      console.log('[XHR] Sending request to:', url);
      xhr.send(uploadData);
    } catch (err) {
      console.error('[XHR] Send failed:', err);
      reject(err);
    }
  });
}

// Upload using Fetch API (fallback method)
async function measureUploadWithFetch(
  url: string,
  size: number,
  onProgress: (speed: number) => void
): Promise<number> {
  console.log('[Fetch] Starting upload test');
  
  const uploadData = new Uint8Array(size);
  try {
    crypto.getRandomValues(uploadData);
  } catch (e) {
    for (let i = 0; i < size; i++) {
      uploadData[i] = Math.floor(Math.random() * 256);
    }
  }
  
  const startTime = performance.now();
  let reportedSpeed = false;
  
  try {
    const response = await fetch(url, {
      method: 'POST',
      body: uploadData,
      headers: {
        'Content-Type': 'application/octet-stream',
      },
    });
    
    const endTime = performance.now();
    const durationS = (endTime - startTime) / 1000;
    
    if (response.ok && durationS > 0) {
      const speedMbps = (size * 8) / (durationS * 1000000);
      console.log('[Fetch] Upload SUCCESS:', {
        bytes: size,
        duration: durationS.toFixed(2),
        speed: speedMbps.toFixed(2)
      });
      onProgress(speedMbps);
      reportedSpeed = true;
      return speedMbps;
    } else {
      throw new Error(`Fetch upload failed: ${response.status}`);
    }
  } catch (error) {
    console.error('[Fetch] Upload error:', error);
    if (reportedSpeed) {
      return 0;
    }
    throw error;
  }
}

// Get browser geolocation coordinates (high accuracy)
async function getBrowserGeolocation(): Promise<{ lat: number; lon: number } | null> {
  return new Promise((resolve) => {
    if (!navigator.geolocation) {
      console.warn('Browser geolocation not supported');
      resolve(null);
      return;
    }

    console.log('Requesting browser geolocation...');
    navigator.geolocation.getCurrentPosition(
      (position) => {
        console.log('Browser geolocation success:', position.coords);
        resolve({
          lat: position.coords.latitude,
          lon: position.coords.longitude,
        });
      },
      (error) => {
        console.warn('Browser geolocation error:', error.message);
        resolve(null);
      },
      {
        enableHighAccuracy: true,
        timeout: 10000,
        maximumAge: 0,
      }
    );
  });
}

// Reverse geocode coordinates to get city/region/country
async function reverseGeocode(lat: number, lon: number): Promise<{ city: string; region: string; country: string }> {
  try {
    console.log(`Reverse geocoding coordinates: lat=${lat}, lon=${lon}`);
    
    // Use Nominatim reverse geocoding (OpenStreetMap) with timeout
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 5000); // 5 second timeout
    
    const response = await fetch(
      `https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lon}&addressdetails=1`,
      {
        headers: {
          'User-Agent': 'SpeedTestApp/1.0',
        },
        signal: controller.signal,
      }
    );
    
    clearTimeout(timeoutId);
    
    if (!response.ok) {
      console.error('Nominatim API error:', response.status, response.statusText);
      return { city: 'Unknown', region: 'Unknown', country: 'Unknown' };
    }
    
    const data = await response.json();
    console.log('Nominatim API response:', data);
    
    if (data.address) {
      const result = {
        city: data.address.city || data.address.town || data.address.village || data.address.municipality || 'Unknown',
        region: data.address.state || data.address.region || data.address.county || 'Unknown',
        country: data.address.country || 'Unknown',
      };
      console.log('Parsed location from Nominatim:', result);
      return result;
    }
  } catch (error) {
    if (error instanceof Error) {
      if (error.name === 'AbortError') {
        console.error('Reverse geocoding timeout after 5 seconds');
      } else {
        console.error('Reverse geocoding error:', error.message);
      }
    } else {
      console.error('Reverse geocoding failed:', error);
    }
  }
  
  console.warn('Reverse geocoding returned no data, using Unknown values');
  return { city: 'Unknown', region: 'Unknown', country: 'Unknown' };
}

// Get IP-based geolocation data with multiple fallbacks
async function getIPBasedGeolocation(): Promise<GeoLocationData | null> {
  console.log('=== Starting IP-based Geolocation ===');
  
  // Method 1: Try ipapi.co (HTTPS, good data)
  try {
    console.log('[API 1/5] Trying ipapi.co...');
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 5000);
    
    const response = await fetch('https://ipapi.co/json/', {
      signal: controller.signal,
    });
    clearTimeout(timeoutId);
    
    if (response.ok) {
      const data = await response.json();
      console.log('[API 1/5] ipapi.co response:', data);
      
      if (data.ip && !data.error) {
        const result = {
          ip: data.ip || 'Unavailable',
          city: data.city || 'Unknown',
          region: data.region || 'Unknown',
          country: data.country_name || data.country || 'Unknown',
          isp: data.org || 'ISP unavailable',
          asn: data.asn || 'Unavailable',
          lat: data.latitude || 0,
          lon: data.longitude || 0,
        };
        console.log('[API 1/5] ✓ SUCCESS with ipapi.co:', result);
        return result;
      }
    }
  } catch (error) {
    console.warn('[API 1/5] ipapi.co failed:', error);
  }
  
  // Method 2: Try ipify.org for IP + ipinfo.io for details
  try {
    console.log('[API 2/5] Trying ipify.org + ipinfo.io...');
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 5000);
    
    // Get IP from ipify
    const ipResponse = await fetch('https://api.ipify.org?format=json', {
      signal: controller.signal,
    });
    
    if (ipResponse.ok) {
      const ipData = await ipResponse.json();
      console.log('[API 2/5] ipify.org IP:', ipData.ip);
      
      if (ipData.ip) {
        // Get geolocation from ipinfo.io
        try {
          const infoResponse = await fetch(`https://ipinfo.io/${ipData.ip}/json`, {
            signal: controller.signal,
          });
          clearTimeout(timeoutId);
          
          if (infoResponse.ok) {
            const info = await infoResponse.json();
            console.log('[API 2/5] ipinfo.io response:', info);
            
            const [lat, lon] = (info.loc || '0,0').split(',').map(Number);
            const result = {
              ip: ipData.ip,
              city: info.city || 'Unknown',
              region: info.region || 'Unknown',
              country: info.country || 'Unknown',
              isp: info.org || 'ISP unavailable',
              asn: info.org?.split(' ')[0] || 'Unavailable',
              lat: lat || 0,
              lon: lon || 0,
            };
            console.log('[API 2/5] ✓ SUCCESS with ipify+ipinfo:', result);
            return result;
          }
        } catch (infoError) {
          console.warn('[API 2/5] ipinfo.io failed:', infoError);
        }
      }
    }
    clearTimeout(timeoutId);
  } catch (error) {
    console.warn('[API 2/5] ipify+ipinfo failed:', error);
  }
  
  // Method 3: Try ip-api.com (HTTPS endpoint with CORS)
  try {
    console.log('[API 3/5] Trying ip-api.com...');
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 5000);
    
    const response = await fetch('http://ip-api.com/json/?fields=status,message,country,regionName,city,lat,lon,isp,as,query', {
      signal: controller.signal,
    });
    clearTimeout(timeoutId);
    
    if (response.ok) {
      const data = await response.json();
      console.log('[API 3/5] ip-api.com response:', data);
      
      if (data.status === 'success' && data.query) {
        const result = {
          ip: data.query,
          city: data.city || 'Unknown',
          region: data.regionName || 'Unknown',
          country: data.country || 'Unknown',
          isp: data.isp || 'ISP unavailable',
          asn: data.as || 'Unavailable',
          lat: data.lat || 0,
          lon: data.lon || 0,
        };
        console.log('[API 3/5] ✓ SUCCESS with ip-api.com:', result);
        return result;
      }
    }
  } catch (error) {
    console.warn('[API 3/5] ip-api.com failed:', error);
  }
  
  // Method 4: Try ipgeolocation.io (free tier, no key needed for basic info)
  try {
    console.log('[API 4/5] Trying ipgeolocation.io...');
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 5000);
    
    const response = await fetch('https://api.ipgeolocation.io/ipgeo?apiKey=', {
      signal: controller.signal,
    });
    clearTimeout(timeoutId);
    
    if (response.ok) {
      const data = await response.json();
      console.log('[API 4/5] ipgeolocation.io response:', data);
      
      if (data.ip) {
        const result = {
          ip: data.ip,
          city: data.city || 'Unknown',
          region: data.state_prov || 'Unknown',
          country: data.country_name || 'Unknown',
          isp: data.isp || 'ISP unavailable',
          asn: data.asn || 'Unavailable',
          lat: parseFloat(data.latitude) || 0,
          lon: parseFloat(data.longitude) || 0,
        };
        console.log('[API 4/5] ✓ SUCCESS with ipgeolocation.io:', result);
        return result;
      }
    }
  } catch (error) {
    console.warn('[API 4/5] ipgeolocation.io failed:', error);
  }
  
  // Method 5: Try basic ipify for IP only as last resort
  try {
    console.log('[API 5/5] Last resort: ipify.org (IP only)...');
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 5000);
    
    const response = await fetch('https://api.ipify.org?format=json', {
      signal: controller.signal,
    });
    clearTimeout(timeoutId);
    
    if (response.ok) {
      const data = await response.json();
      console.log('[API 5/5] ipify.org IP-only response:', data);
      
      if (data.ip) {
        const result = {
          ip: data.ip,
          city: 'Unknown',
          region: 'Unknown',
          country: 'Unknown',
          isp: 'ISP unavailable',
          asn: 'Unavailable',
          lat: 0,
          lon: 0,
        };
        console.log('[API 5/5] ✓ Partial success (IP only):', result);
        return result;
      }
    }
  } catch (error) {
    console.warn('[API 5/5] Final fallback failed:', error);
  }
  
  console.error('❌ ALL geolocation APIs failed');
  return null;
}

// Get geolocation data with multi-tiered fallback strategy
export async function getGeoLocationData(
  onStatusUpdate?: (status: string) => void
): Promise<GeoLocationData> {
  console.log('=== Starting Geolocation Detection ===');
  onStatusUpdate?.('Iniciando detección de ubicación...');
  
  // Always get IP-based data first (for IP, ISP, ASN info)
  console.log('Step 1: Getting IP-based geolocation data...');
  onStatusUpdate?.('Obteniendo datos de IP...');
  const ipData = await getIPBasedGeolocation();
  console.log('IP-based data retrieved:', ipData);
  
  if (ipData) {
    onStatusUpdate?.(`IP: ${ipData.city}, ${ipData.region}, ${ipData.country}`);
  }
  
  // Strategy 1: Try browser geolocation first (most accurate coordinates)
  console.log('Step 2: Attempting browser geolocation...');
  onStatusUpdate?.('Solicitando ubicación precisa...');
  const browserCoords = await getBrowserGeolocation();
  
  if (browserCoords) {
    console.log('Browser geolocation SUCCESS:', browserCoords);
    onStatusUpdate?.('Coordenadas GPS obtenidas');
    
    // Get location details from reverse geocoding
    console.log('Step 3: Reverse geocoding coordinates...');
    onStatusUpdate?.('Convirtiendo coordenadas a ubicación...');
    const locationDetails = await reverseGeocode(browserCoords.lat, browserCoords.lon);
    console.log('Reverse geocoding result:', locationDetails);
    
    // Check if reverse geocoding gave us real data (not all "Unknown")
    const hasValidLocation = locationDetails.city !== 'Unknown' || 
                            locationDetails.region !== 'Unknown' || 
                            locationDetails.country !== 'Unknown';
    
    if (hasValidLocation) {
      console.log('Using browser geolocation + reverse geocoding');
      const finalLocation = `${locationDetails.city}, ${locationDetails.region}, ${locationDetails.country}`;
      onStatusUpdate?.(`✓ Ubicación: ${finalLocation}`);
      return {
        ip: ipData?.ip || 'Unavailable',
        city: locationDetails.city,
        region: locationDetails.region,
        country: locationDetails.country,
        isp: ipData?.isp || 'ISP unavailable',
        asn: ipData?.asn || 'Unavailable',
        lat: browserCoords.lat,
        lon: browserCoords.lon,
      };
    } else {
      // Reverse geocoding failed, fall back to IP-based location but keep browser coordinates
      console.warn('Reverse geocoding failed, using IP-based location with browser coordinates');
      if (ipData) {
        const finalLocation = `${ipData.city}, ${ipData.region}, ${ipData.country}`;
        onStatusUpdate?.(`✓ Ubicación (IP): ${finalLocation}`);
        return {
          ...ipData,
          lat: browserCoords.lat,
          lon: browserCoords.lon,
        };
      }
    }
  } else {
    console.log('Browser geolocation not available or denied');
    onStatusUpdate?.('Ubicación GPS no disponible, usando IP');
  }
  
  // Strategy 2: Use IP-based geolocation
  if (ipData) {
    console.log('Using IP-based geolocation');
    const finalLocation = `${ipData.city}, ${ipData.region}, ${ipData.country}`;
    onStatusUpdate?.(`✓ Ubicación (IP): ${finalLocation}`);
    return ipData;
  }
  
  // Strategy 3: Return defaults if all methods fail
  console.warn('All geolocation methods failed, returning defaults');
  onStatusUpdate?.('⚠ No se pudo determinar la ubicación');
  return {
    ip: 'Unavailable',
    city: 'Unknown',
    region: 'Unknown',
    country: 'Unknown',
    isp: 'ISP unavailable',
    asn: 'Unavailable',
    lat: 0,
    lon: 0,
  };
}

// Calculate distance between two coordinates (Haversine formula)
function calculateDistance(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 6371; // Radius of the Earth in km
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;
  const a = 
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
    Math.sin(dLon / 2) * Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  const distance = R * c; // Distance in km
  return Math.round(distance);
}

// Main speed test function
export async function runSpeedTest(
  onStateUpdate: (state: Partial<SpeedTestState>) => void,
  onLocationUpdate?: (status: string) => void
): Promise<SpeedTestResult> {
  const server = TEST_CONFIG.TEST_SERVERS[0];
  
  try {
    // Get geolocation data before starting the test
    console.log('Step 1: Getting geolocation data');
    const geoData = await getGeoLocationData(onLocationUpdate);
    console.log('Geolocation data retrieved:', geoData);
    
    // Calculate distance to server
    const distance = calculateDistance(
      geoData.lat,
      geoData.lon,
      server.lat,
      server.lon
    );
    console.log('Distance to server:', distance, 'km');
    
    // Phase 1: Measure latency
    console.log('Step 2: Measuring latency');
    onStateUpdate({ phase: 'ping', progress: 10 });
    const { ping, jitter } = await measureLatency(server.url);
    console.log('Latency measured - Ping:', ping, 'Jitter:', jitter);
    onStateUpdate({ ping, jitter, progress: 25 });
    
    // Phase 2: Measure download speed
    console.log('Step 3: Measuring download speed');
    onStateUpdate({ phase: 'download', progress: 30 });
    const downloadSpeed = await measureDownloadSpeed(
      server.url,
      TEST_CONFIG.DOWNLOAD_SIZE,
      (speed) => onStateUpdate({ downloadSpeed: speed })
    );
    console.log('Download speed measured:', downloadSpeed, 'Mbps');
    onStateUpdate({ downloadSpeed, progress: 60 });
    
    // Phase 3: Measure upload speed with retry logic and multiple endpoints
    console.log('Step 4: Measuring upload speed');
    onStateUpdate({ phase: 'upload', progress: 65 });
    let uploadSpeed = 0;
    let uploadAttempts = 0;
    const maxUploadAttempts = 3;
    const uploadUrls = [server.uploadUrl, ...TEST_CONFIG.ALTERNATIVE_UPLOAD_URLS];
    
    // Try each URL with retries
    for (const uploadUrl of uploadUrls) {
      if (uploadSpeed > 0) break; // Success, stop trying
      
      uploadAttempts = 0;
      console.log(`Trying upload endpoint: ${uploadUrl}`);
      
      while (uploadAttempts < maxUploadAttempts && uploadSpeed === 0) {
        try {
          console.log(`Upload attempt ${uploadAttempts + 1}/${maxUploadAttempts} on ${uploadUrl}`);
          uploadSpeed = await measureUploadSpeed(
            uploadUrl,
            TEST_CONFIG.UPLOAD_SIZE,
            (speed) => {
              console.log('Upload progress callback:', speed.toFixed(2), 'Mbps');
              onStateUpdate({ uploadSpeed: speed });
            }
          );
          console.log(`✓ Upload speed measured: ${uploadSpeed.toFixed(2)} Mbps`);
          break; // Success
        } catch (error) {
          uploadAttempts++;
          console.error(`Upload attempt ${uploadAttempts} failed on ${uploadUrl}:`, error);
          
          if (uploadAttempts >= maxUploadAttempts) {
            console.warn(`All ${maxUploadAttempts} attempts failed on ${uploadUrl}, trying next endpoint...`);
          } else {
            console.log('Waiting 1 second before retry...');
            await new Promise(resolve => setTimeout(resolve, 1000));
          }
        }
      }
    }
    
    // Final fallback: if all attempts failed, log detailed error
    if (uploadSpeed === 0) {
      console.error('❌ Upload test FAILED after all attempts on all endpoints');
      console.error('This may be due to:');
      console.error('1. Network firewall blocking upload requests');
      console.error('2. CloudFlare endpoint temporarily unavailable');
      console.error('3. CORS issues with upload endpoints');
      console.error('4. Browser security restrictions');
      // Don't throw - continue with 0 upload speed
    } else {
      console.log(`✓ Upload test completed successfully: ${uploadSpeed.toFixed(2)} Mbps`);
    }
    
    onStateUpdate({ uploadSpeed, progress: 95 });
    
    // Phase 4: Complete
    console.log('Test complete!');
    onStateUpdate({ phase: 'complete', progress: 100 });
    
    const result = {
      downloadSpeed,
      uploadSpeed,
      ping,
      jitter,
      serverName: server.name,
      serverLocation: server.location,
      serverDistance: distance,
      ipAddress: geoData.ip,
      isp: geoData.isp,
      asn: geoData.asn,
      userLocation: `${geoData.city}, ${geoData.region}, ${geoData.country}`,
      timestamp: new Date(),
    };
    
    console.log('Final test result:', result);
    return result;
  } catch (error) {
    console.error('Speed test failed:', error);
    onStateUpdate({
      phase: 'error',
      error: error instanceof Error ? error.message : 'Error desconocido',
    });
    throw error;
  }
}

// Get user's IP address (standalone function)
export async function getUserIP(): Promise<string> {
  try {
    const response = await fetch('https://api.ipify.org?format=json');
    const data = await response.json();
    return data.ip;
  } catch (error) {
    console.error('Failed to get IP:', error);
    return 'No disponible';
  }
}

// Save test result to localStorage
export function saveTestResult(result: SpeedTestResult): void {
  const stored = localStorage.getItem('speedTestHistory');
  const history: SpeedTestResult[] = stored ? JSON.parse(stored) : [];
  
  history.unshift(result);
  
  // Keep only last 5 results
  if (history.length > 5) {
    history.splice(5);
  }
  
  localStorage.setItem('speedTestHistory', JSON.stringify(history));
}

// Get test history from localStorage
export function getTestHistory(): SpeedTestResult[] {
  const stored = localStorage.getItem('speedTestHistory');
  return stored ? JSON.parse(stored) : [];
}
