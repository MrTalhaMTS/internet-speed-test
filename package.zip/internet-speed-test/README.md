# Internet Speed Test Application

Professional internet speed testing application with comprehensive network detection capabilities.

![Version](https://img.shields.io/badge/version-1.0.0-blue.svg)
![License](https://img.shields.io/badge/license-MIT-green.svg)
![React](https://img.shields.io/badge/React-18.3-61dafb.svg)
![TypeScript](https://img.shields.io/badge/TypeScript-5.6-3178c6.svg)

## 🚀 Features

### Speed Testing
- **Download Speed**: Accurately measures download throughput up to 100+ Mbps
- **Upload Speed**: Dual-method testing (XHR + Fetch API fallback) for reliability
- **Ping/Latency**: 5-sample average for accurate latency measurement
- **Jitter**: Calculates latency variation for connection stability assessment

### Network Detection
- **IP Address**: Multi-source IP detection with 5-API fallback system
- **ISP Identification**: Detects Internet Service Provider from multiple sources
- **ASN Detection**: Identifies Autonomous System Number
- **Geolocation**: Determines city, region, and country with high accuracy
- **Distance Calculation**: Computes distance to test server using Haversine formula

### User Interface
- **5 Pages**: Home (speed test), Information, Contact, Privacy
- **Real-time Gauges**: Animated speedometer displays with smooth transitions
- **Responsive Design**: Optimized for mobile, tablet, and desktop
- **Dark Theme**: Cyber blue color scheme with professional aesthetics
- **Spanish Interface**: Complete Spanish language localization
- **Social Sharing**: Built-in sharing functionality for test results

## 🛠️ Tech Stack

- **Framework**: React 18.3 with TypeScript
- **Build Tool**: Vite 6.0
- **Styling**: TailwindCSS 3.4 with custom design tokens
- **Routing**: React Router 6
- **Animations**: Framer Motion
- **Icons**: Lucide React
- **UI Components**: Custom components with Radix UI primitives

## 📋 Prerequisites

- **Node.js**: 18.x or higher
- **npm**: 9.x or higher (or pnpm 8.x+)
- **Git**: For version control

## 🔧 Installation

### Local Development

1. **Clone the repository**:
   ```bash
   git clone <repository-url>
   cd internet-speed-test
   ```

2. **Install dependencies**:
   ```bash
   npm install
   ```

3. **Start development server**:
   ```bash
   npm run dev
   ```

4. **Open in browser**:
   - Navigate to `http://localhost:5173`
   - Speed test interface will load automatically

### Production Build

```bash
# Build for production
npm run build

# Preview production build locally
npm run preview
```

The production build will be generated in the `dist/` directory.

## 🚀 Deployment

### Deploy to Vercel (Recommended)

**Quick Deploy**:
1. Push code to GitHub/GitLab/Bitbucket
2. Import project at [vercel.com/new](https://vercel.com/new)
3. Vercel auto-detects settings from `vercel.json`
4. Click "Deploy"
5. Your site will be live in 2-3 minutes

**Configuration Included**:
- ✅ `vercel.json` - Deployment configuration
- ✅ SPA routing setup
- ✅ Security headers
- ✅ Asset caching optimization

**See detailed instructions**: [VERCEL_DEPLOYMENT_GUIDE.md](./VERCEL_DEPLOYMENT_GUIDE.md)

### Alternative Platforms

**Netlify**:
```bash
npm run build
# Deploy the dist/ folder via Netlify CLI or drag-and-drop
```

**GitHub Pages** (requires base path configuration):
```bash
# Update vite.config.ts with base: '/repo-name/'
npm run build
# Deploy dist/ to gh-pages branch
```

## 📁 Project Structure

```
internet-speed-test/
├── public/                  # Static assets
│   ├── favicon.ico         # Browser favicon
│   ├── logo-512.png        # PWA icon
│   └── site.webmanifest    # PWA manifest
├── src/
│   ├── components/         # React components
│   │   ├── Speedometer.tsx # Animated gauge component
│   │   ├── Navigation.tsx  # Header navigation
│   │   └── Footer.tsx      # Footer component
│   ├── pages/              # Page components
│   │   ├── HomePage.tsx    # Speed test page
│   │   ├── InformationPage.tsx
│   │   ├── ContactPage.tsx
│   │   └── PrivacyPage.tsx
│   ├── lib/                # Core logic
│   │   └── speedTest.ts   # Speed testing engine
│   ├── App.tsx             # Root component
│   ├── main.tsx            # Entry point
│   └── index.css           # Global styles
├── vercel.json             # Vercel configuration
├── package.json            # Dependencies & scripts
├── vite.config.ts          # Vite configuration
├── tailwind.config.js      # Tailwind configuration
├── tsconfig.json           # TypeScript configuration
└── VERCEL_DEPLOYMENT_GUIDE.md  # Deployment instructions
```

## 🧪 Testing

### Manual Testing

1. **Start Test**: Click "Iniciar Test" button
2. **Monitor Progress**: Watch gauges animate during test (~35 seconds)
3. **Verify Results**: Check that all fields show real values:
   - Download Speed: > 0 Mbps
   - Upload Speed: > 0 Mbps (not "0.0")
   - Ping: > 0 ms
   - IP Address: Real IP (not "Unavailable")
   - ISP: Provider name (not "ISP unavailable")
   - Location: "City, Region, Country" (not "Unknown")

### Browser Console Verification

Open DevTools (F12) and check for success logs:
```
=== Starting IP-based Geolocation ===
[API 1/5] ✓ SUCCESS with ipapi.co: {...}
[XHR] Upload SUCCESS: {...}
✓ Upload test completed successfully: X.XX Mbps
```

## 🔍 How It Works

### Speed Testing Algorithm

1. **Geolocation Phase**:
   - Attempts browser geolocation (with user permission)
   - Falls back to IP-based geolocation (5 API cascade)
   - Calculates distance to test server

2. **Ping/Latency Phase**:
   - Sends 5 small requests to test server
   - Measures round-trip time for each
   - Calculates average ping and jitter (variance)

3. **Download Phase**:
   - Fetches 25MB file from CloudFlare CDN
   - Measures bytes received over time
   - Calculates speed in Mbps (real-time updates)

4. **Upload Phase**:
   - Generates 5MB random data buffer
   - Primary: XMLHttpRequest with progress tracking
   - Fallback: Fetch API if XHR fails
   - Multiple retry attempts for reliability

### Network Detection

**5-API Cascade System**:
1. **ipapi.co** - Full geolocation data
2. **ipify.org + ipinfo.io** - IP + location details
3. **ip-api.com** - Alternative geolocation service
4. **ipgeolocation.io** - Additional fallback
5. **ipify.org** - IP-only minimal fallback

Each API has 5-second timeout protection and graceful failure handling.

## 🔒 Security & Privacy

- **No Backend**: Pure client-side application
- **HTTPS Only**: All API calls use secure connections
- **No Data Collection**: No user data stored on servers
- **Local Storage Only**: Test history stored in browser
- **No Tracking**: No analytics or tracking scripts
- **Public APIs**: Uses free, public geolocation services

## 🎨 Customization

### Design Tokens

Edit design tokens in `tailwind.config.js`:
```javascript
theme: {
  extend: {
    colors: {
      primary: { ... },  // Cyber blue colors
      accent: { ... },   // Accent colors
    }
  }
}
```

### Language

Currently Spanish. To add English:
1. Create translation constants in `src/lib/i18n.ts`
2. Replace hardcoded Spanish text with translation keys
3. Add language switcher component

### Speed Test Configuration

Edit `src/lib/speedTest.ts`:
```typescript
export const TEST_CONFIG = {
  DOWNLOAD_SIZE: 25 * 1024 * 1024,  // 25MB
  UPLOAD_SIZE: 5 * 1024 * 1024,     // 5MB
  TEST_DURATION: 10000,              // 10 seconds
  // Add more servers for load balancing
  TEST_SERVERS: [ ... ]
};
```

## 📊 Performance

### Lighthouse Scores (Target)
- **Performance**: 95+
- **Accessibility**: 95+
- **Best Practices**: 95+
- **SEO**: 90+

### Build Size
- **JavaScript**: ~480 KB (gzipped: ~120 KB)
- **CSS**: ~19 KB (gzipped: ~4.5 KB)
- **Total**: ~500 KB initial load

### Loading Time
- **First Contentful Paint**: < 1.5s
- **Time to Interactive**: < 3.0s
- **Speed Test Complete**: 30-40s (depends on connection)

## 🐛 Known Issues & Solutions

### Upload Speed Shows 0.0 Mbps
**Cause**: Network firewall or CORS restrictions  
**Solution**: Check browser console for error logs, try different network

### Location Shows "Unknown"
**Cause**: All 5 geolocation APIs failed or are rate-limited  
**Solution**: Wait a few minutes and retry, check console for API errors

### 404 on Page Refresh
**Cause**: Server not configured for SPA routing  
**Solution**: Use included `vercel.json` configuration (already configured)

## 🤝 Contributing

Contributions welcome! Please:
1. Fork the repository
2. Create a feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit changes (`git commit -m 'Add AmazingFeature'`)
4. Push to branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

## 📄 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 🙏 Acknowledgments

- **CloudFlare**: Speed test endpoints
- **ipapi.co, ipify.org, ipinfo.io**: Geolocation services
- **Lucide**: Icon library
- **Vercel**: Hosting platform

## 📞 Support

For issues or questions:
1. Check [VERCEL_DEPLOYMENT_GUIDE.md](./VERCEL_DEPLOYMENT_GUIDE.md)
2. Review browser console logs
3. Open an issue on GitHub

---

**Built with ❤️ using React, TypeScript, and Vite**

*Last Updated: 2025-11-05*  
*Version: 1.0.0*

