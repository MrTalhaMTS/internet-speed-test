/** @type {import('tailwindcss').Config} */
module.exports = {
  darkMode: ['class'],
  content: [
    './pages/**/*.{ts,tsx}',
    './components/**/*.{ts,tsx}',
    './app/**/*.{ts,tsx}',
    './src/**/*.{ts,tsx}',
  ],
  theme: {
    container: {
      center: true,
      padding: '2rem',
      screens: {
        '2xl': '1400px',
      },
    },
    extend: {
      colors: {
        // Background surfaces (Dark Layered Depth)
        bg: {
          base: '#0E1117',
          elevated: '#161B22',
          hover: '#21262D',
          modal: '#2D333B',
        },
        // Text colors
        text: {
          primary: '#FFFFFF',
          secondary: '#E6EDF3',
          tertiary: '#8D96A0',
          muted: '#6E7681',
        },
        // Primary colors
        primary: {
          400: '#409CFF',
          500: '#007AFF',
          600: '#0062CC',
          DEFAULT: '#007AFF',
        },
        // Accent colors
        accent: {
          green: '#32D74B',
          DEFAULT: '#32D74B',
        },
        // Semantic colors
        success: '#32D74B',
        warning: '#FFD60A',
        error: '#FF453A',
        info: '#64D2FF',
        // Borders
        border: {
          subtle: 'rgba(255, 255, 255, 0.08)',
          default: 'rgba(255, 255, 255, 0.12)',
          strong: 'rgba(255, 255, 255, 0.18)',
          accent: '#007AFF',
        },
        // Glows
        glow: {
          primary: 'rgba(0, 122, 255, 0.5)',
          green: 'rgba(50, 215, 75, 0.4)',
        },
      },
      fontFamily: {
        sans: ['Inter', '-apple-system', 'BlinkMacSystemFont', 'Segoe UI', 'sans-serif'],
        display: ['Inter', 'sans-serif'],
        mono: ['JetBrains Mono', 'Fira Code', 'Courier New', 'monospace'],
      },
      fontSize: {
        hero: ['56px', { lineHeight: '1.1', letterSpacing: '-0.02em', fontWeight: '700' }],
        h1: ['40px', { lineHeight: '1.15', letterSpacing: '-0.015em', fontWeight: '700' }],
        h2: ['32px', { lineHeight: '1.2', letterSpacing: '-0.01em', fontWeight: '600' }],
        h3: ['24px', { lineHeight: '1.25', letterSpacing: '0', fontWeight: '600' }],
        large: ['18px', { lineHeight: '1.6', letterSpacing: '0', fontWeight: '400' }],
        base: ['16px', { lineHeight: '1.5', letterSpacing: '0', fontWeight: '400' }],
        small: ['14px', { lineHeight: '1.5', letterSpacing: '0.005em', fontWeight: '400' }],
        metric: ['64px', { lineHeight: '1.0', letterSpacing: '-0.02em', fontWeight: '700' }],
        code: ['14px', { lineHeight: '1.4', letterSpacing: '0', fontWeight: '400' }],
      },
      spacing: {
        1: '4px',
        2: '8px',
        3: '12px',
        4: '16px',
        6: '24px',
        8: '32px',
        12: '48px',
        16: '64px',
        20: '80px',
        24: '96px',
      },
      borderRadius: {
        sm: '8px',
        md: '12px',
        lg: '16px',
        xl: '24px',
        full: '9999px',
      },
      boxShadow: {
        card: '0 0 0 1px rgba(255,255,255,0.05), 0 4px 12px rgba(0,0,0,0.4)',
        modal: '0 0 0 1px rgba(255,255,255,0.08), 0 8px 24px rgba(0,0,0,0.6)',
        'glow-button': '0 0 20px rgba(0,122,255,0.5), 0 0 40px rgba(0,122,255,0.3)',
        'glow-metric': '0 0 16px rgba(0,122,255,0.4)',
        'glow-success': '0 0 16px rgba(50,215,75,0.4)',
      },
      animation: {
        'accordion-down': 'accordion-down 0.2s ease-out',
        'accordion-up': 'accordion-up 0.2s ease-out',
        'needle-rotate': 'needle-rotate 800ms ease-out',
        'glow-pulse': 'glow-pulse 2s ease-in-out',
      },
      keyframes: {
        'accordion-down': {
          from: { height: '0' },
          to: { height: 'var(--radix-accordion-content-height)' },
        },
        'accordion-up': {
          from: { height: 'var(--radix-accordion-content-height)' },
          to: { height: '0' },
        },
        'needle-rotate': {
          from: { transform: 'rotate(0deg)' },
          to: { transform: 'rotate(var(--target-rotation))' },
        },
        'glow-pulse': {
          '0%, 100%': { opacity: '0' },
          '50%': { opacity: '1' },
        },
      },
      transitionDuration: {
        fast: '150ms',
        base: '250ms',
        slow: '400ms',
        metric: '800ms',
      },
      transitionTimingFunction: {
        standard: 'ease-out',
        sharp: 'cubic-bezier(0.4, 0.0, 0.2, 1)',
      },
    },
  },
  plugins: [require('tailwindcss-animate')],
}
